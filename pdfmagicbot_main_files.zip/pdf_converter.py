import base64
import io
import os
import tempfile
import binascii
from datetime import datetime
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import A4
from PIL import Image
from PyPDF2 import PdfWriter, PdfReader

class PDFConverter:
    def __init__(self):
        """Initialize the PDF converter."""
        pass
    
    def convert_to_pdf(self, file_content, filename):
        """
        Convert a file to PDF format using Python's standard library.
        
        Args:
            file_content: Binary content of the file
            filename: Original filename with extension
            
        Returns:
            Tuple of (success, result_or_error_message)
        """
        try:
            # Get file extension
            _, ext = os.path.splitext(filename)
            ext = ext.lower().strip('.')
            
            # Create PDF based on file type
            if ext in ['txt', 'html', 'md', 'rtf', 'doc', 'docx']:
                return self._convert_text_to_pdf(file_content, filename, ext)
            elif ext in ['jpg', 'jpeg', 'png', 'bmp']:
                return self._convert_image_to_pdf(file_content, filename, ext)
            else:
                return False, f"Unsupported file format: {ext}"
                
        except Exception as e:
            return False, f"Conversion error: {str(e)}"
    
    def _convert_text_to_pdf(self, file_content, filename, ext):
        """
        Convert text-based files to PDF using ReportLab.
        This provides better formatting and support for various text encodings.
        """
        try:
            # Try to detect encoding and decode text
            try:
                if ext in ['doc', 'docx', 'rtf']:
                    # For complex formats, we extract what text we can
                    text_content = self._extract_text_from_binary(file_content)
                else:
                    # For plain text formats
                    text_content = file_content.decode('utf-8', errors='replace')
            except UnicodeDecodeError:
                text_content = file_content.decode('latin-1', errors='replace')
            
            # Create a PDF with reportlab
            pdf_buffer = io.BytesIO()
            
            # Set up the PDF canvas with A4 page size
            c = canvas.Canvas(pdf_buffer, pagesize=A4)
            width, height = A4
            
            # Set title and metadata
            c.setTitle(f"Converted: {filename}")
            c.setAuthor("PDFMagicBot")
            c.setSubject("Converted from text document")
            
            # Set up font settings
            c.setFont("Helvetica-Bold", 16)
            
            # Add title
            title = f"Document: {filename}"
            c.drawString(50, height - 50, title)
            
            # Add date
            c.setFont("Helvetica", 10)
            date_str = f"Created: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
            c.drawString(50, height - 70, date_str)
            
            # Set up for main content
            c.setFont("Helvetica", 12)
            y_position = height - 100
            line_height = 15
            margin = 50
            
            # Break text into lines
            lines = text_content.replace('\r\n', '\n').replace('\r', '\n').split('\n')
            
            # Process each line
            for line in lines:
                if line.strip():  # Skip empty lines
                    # Check if we need a new page
                    if y_position < margin:
                        c.showPage()
                        y_position = height - margin
                        c.setFont("Helvetica", 12)
                    
                    # Draw the line of text
                    c.drawString(margin, y_position, line)
                    y_position -= line_height
            
            # Save the PDF
            c.save()
            
            # Generate a filename for the output PDF
            base_name = os.path.splitext(filename)[0]
            output_filename = f"{base_name}.pdf"
            
            # Reset buffer position
            pdf_buffer.seek(0)
            
            # Debug logs
            print(f"Converting text file: {filename}, ext: {ext}")
            print(f"Output PDF size: {pdf_buffer.tell()} bytes")
            
            return True, (pdf_buffer, output_filename)
            
        except Exception as e:
            import traceback
            traceback.print_exc()
            return False, f"Text conversion error: {str(e)}"
    
    def _convert_image_to_pdf(self, file_content, filename, ext):
        """
        Convert image files to PDF using Pillow and ReportLab.
        This ensures proper image display and high quality output.
        """
        try:
            # Create a BytesIO object from the image data
            img_data = io.BytesIO(file_content)
            
            # Open the image with PIL
            img = Image.open(img_data)
            
            # Resize if necessary while maintaining aspect ratio
            img_width, img_height = img.size
            
            # Get A4 dimensions in points
            a4_width, a4_height = A4  # (595.276, 841.890) points
            
            # Calculate scaling factors to fit within A4 while preserving aspect ratio
            width_ratio = a4_width / img_width
            height_ratio = a4_height / img_height
            scale_factor = min(width_ratio, height_ratio) * 0.95  # 5% margin
            
            # Calculate new dimensions
            new_width = int(img_width * scale_factor)
            new_height = int(img_height * scale_factor)
            
            # Calculate positioning for centering
            x_pos = (a4_width - new_width) / 2
            y_pos = (a4_height - new_height) / 2
            
            # Create a PDF with reportlab
            pdf_buffer = io.BytesIO()
            c = canvas.Canvas(pdf_buffer, pagesize=A4)
            
            # Save the image to a temporary location
            temp_img = io.BytesIO()
            
            # Convert image to RGB mode if it's RGBA
            if img.mode == 'RGBA':
                img = img.convert('RGB')
                
            # Save the image in a format reportlab can handle
            img.save(temp_img, format='JPEG' if ext.lower() in ['jpg', 'jpeg'] else 'PNG')
            temp_img.seek(0)
            
            # Draw the image on the canvas - passing the file-like object to ImageReader
            from reportlab.lib.utils import ImageReader
            img_reader = ImageReader(temp_img)
            c.drawImage(img_reader, x_pos, y_pos, width=new_width, height=new_height)
            
            # Add some metadata
            c.setTitle(filename)
            c.setAuthor("PDFMagicBot")
            c.setSubject("Converted from image")
            
            # Save the PDF
            c.save()
            
            # Generate a filename for the output PDF
            base_name = os.path.splitext(filename)[0]
            output_filename = f"{base_name}.pdf"
            
            # Set buffer position to beginning
            pdf_buffer.seek(0)
            
            # Debug logs
            print(f"Converting image: {filename}, ext: {ext}")
            print(f"Image dimensions: {img_width}x{img_height}")
            print(f"New PDF dimensions: {new_width}x{new_height}")
            print(f"Output PDF size: {pdf_buffer.tell()} bytes")
            
            # Return the result
            return True, (pdf_buffer, output_filename)
            
        except Exception as e:
            import traceback
            traceback.print_exc()
            return False, f"Image conversion error: {str(e)}"
    
    def _create_basic_pdf(self):
        """Create a basic PDF structure."""
        # PDF file format basic structure
        pdf = io.BytesIO()
        
        # PDF header
        pdf.write(b"%PDF-1.7\n")
        
        # PDF objects
        obj_positions = []
        
        # Object 1: Catalog
        obj_positions.append(pdf.tell())
        pdf.write(b"1 0 obj\n")
        pdf.write(b"<< /Type /Catalog /Pages 2 0 R >>\n")
        pdf.write(b"endobj\n")
        
        # Object 2: Pages
        obj_positions.append(pdf.tell())
        pdf.write(b"2 0 obj\n")
        pdf.write(b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>\n")
        pdf.write(b"endobj\n")
        
        # Object 3: Page
        obj_positions.append(pdf.tell())
        pdf.write(b"3 0 obj\n")
        pdf.write(b"<< /Type /Page /Parent 2 0 R /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R /MediaBox [0 0 612 792] >>\n")
        pdf.write(b"endobj\n")
        
        # Object 4: Font
        obj_positions.append(pdf.tell())
        pdf.write(b"4 0 obj\n")
        pdf.write(b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>\n")
        pdf.write(b"endobj\n")
        
        # Object 5: Content stream placeholder (will be filled later)
        obj_positions.append(pdf.tell())
        pdf.write(b"5 0 obj\n")
        pdf.write(b"<< /Length 0 >>\n")
        pdf.write(b"stream\n")
        pdf.write(b"endstream\n")
        pdf.write(b"endobj\n")
        
        # Cross-reference table
        xref_position = pdf.tell()
        pdf.write(b"xref\n")
        pdf.write(f"0 {len(obj_positions) + 1}\n".encode())
        pdf.write(b"0000000000 65535 f \n")
        for pos in obj_positions:
            pdf.write(f"{pos:010d} 00000 n \n".encode())
        
        # Trailer
        pdf.write(b"trailer\n")
        pdf.write(f"<< /Size {len(obj_positions) + 1} /Root 1 0 R >>\n".encode())
        pdf.write(b"startxref\n")
        pdf.write(f"{xref_position}\n".encode())
        pdf.write(b"%%EOF\n")
        
        return pdf
    
    def _add_text_to_pdf(self, pdf, text, filename):
        """Add text content to the PDF."""
        # Convert text to PDF content stream format
        content = io.BytesIO()
        content.write(b"BT\n")
        content.write(b"/F1 12 Tf\n")
        content.write(b"36 720 Td\n")
        
        # Add title
        content.write(b"/F1 16 Tf\n")
        title = f"Document: {filename}"
        content.write(f"({self._escape_pdf_string(title)}) Tj\n".encode())
        content.write(b"0 -30 Td\n")
        
        # Add date
        content.write(b"/F1 10 Tf\n")
        date_str = f"Created: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        content.write(f"({self._escape_pdf_string(date_str)}) Tj\n".encode())
        content.write(b"0 -20 Td\n")
        
        # Restore normal font
        content.write(b"/F1 12 Tf\n")
        
        # Break text into lines
        lines = text.replace('\r\n', '\n').replace('\r', '\n').split('\n')
        y_position = 650  # Starting Y position

        # Write lines
        for line in lines:
            if line.strip():  # Skip empty lines
                safe_line = self._escape_pdf_string(line)
                content.write(f"0 {y_position} Td\n".encode())
                content.write(f"({safe_line}) Tj\n".encode())
                y_position -= 15  # Move down for next line
                
                # If we're near the bottom of the page, reset position
                if y_position < 50:
                    y_position = 750

        content.write(b"ET\n")
        
        # Update the content stream
        content_data = content.getvalue()
        
        # Read the existing PDF
        pdf_data = pdf.getvalue()
        
        # Find the content stream object (object 5)
        obj5_start = pdf_data.find(b"5 0 obj")
        obj5_end = pdf_data.find(b"endobj", obj5_start)
        
        # Replace content stream
        new_obj5 = f"5 0 obj\n<< /Length {len(content_data)} >>\nstream\n".encode() + content_data + b"\nendstream\nendobj\n"
        
        # Construct new PDF
        new_pdf = io.BytesIO()
        new_pdf.write(pdf_data[:obj5_start])
        new_pdf.write(new_obj5)
        new_pdf.write(pdf_data[obj5_end + 7:])  # +7 for "endobj\n"
        
        new_pdf.seek(0)
        return new_pdf
    
    def _create_image_pdf(self, image_data, ext):
        """
        Create a PDF containing an image.
        This is a simplified implementation that embeds the image directly.
        The image will be displayed at full size on the page.
        """
        # Create an empty PDF
        pdf = io.BytesIO()
        
        # PDF header
        pdf.write(b"%PDF-1.7\n")
        
        # PDF objects
        obj_positions = []
        
        # Object 1: Catalog
        obj_positions.append(pdf.tell())
        pdf.write(b"1 0 obj\n")
        pdf.write(b"<< /Type /Catalog /Pages 2 0 R >>\n")
        pdf.write(b"endobj\n")
        
        # Object 2: Pages
        obj_positions.append(pdf.tell())
        pdf.write(b"2 0 obj\n")
        pdf.write(b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>\n")
        pdf.write(b"endobj\n")
        
        # Object 3: Page - Using a standard A4 page size (595 x 842 points)
        obj_positions.append(pdf.tell())
        pdf.write(b"3 0 obj\n")
        pdf.write(b"<< /Type /Page /Parent 2 0 R /Resources << /XObject << /Im0 4 0 R >> >> /Contents 5 0 R /MediaBox [0 0 595 842] >>\n")
        pdf.write(b"endobj\n")
        
        # Object 4: Image
        obj_positions.append(pdf.tell())
        pdf.write(b"4 0 obj\n")
        
        # For simplicity, we'll use the image data directly
        # In real applications, this would need proper image format handling
        if ext in ['jpg', 'jpeg']:
            pdf.write(b"<< /Type /XObject /Subtype /Image /Width 595 /Height 842 /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ")
        elif ext == 'png':
            # Simplified - real implementation would need to handle PNG data properly
            pdf.write(b"<< /Type /XObject /Subtype /Image /Width 595 /Height 842 /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /FlateDecode /Length ")
        else:  # bmp or other format
            pdf.write(b"<< /Type /XObject /Subtype /Image /Width 595 /Height 842 /ColorSpace /DeviceRGB /BitsPerComponent 8 /Length ")
        
        pdf.write(f"{len(image_data)} >>\n".encode())
        pdf.write(b"stream\n")
        pdf.write(image_data)
        pdf.write(b"\nendstream\n")
        pdf.write(b"endobj\n")
        
        # Object 5: Content stream - Adjust position to center the image on page and scale to fit
        # This scales and positions the image to fill the entire page without cropping
        content = b"q\n595 0 0 842 0 0 cm\n/Im0 Do\nQ"
        obj_positions.append(pdf.tell())
        pdf.write(b"5 0 obj\n")
        pdf.write(f"<< /Length {len(content)} >>\n".encode())
        pdf.write(b"stream\n")
        pdf.write(content)
        pdf.write(b"\nendstream\n")
        pdf.write(b"endobj\n")
        
        # Cross-reference table
        xref_position = pdf.tell()
        pdf.write(b"xref\n")
        pdf.write(f"0 {len(obj_positions) + 1}\n".encode())
        pdf.write(b"0000000000 65535 f \n")
        for pos in obj_positions:
            pdf.write(f"{pos:010d} 00000 n \n".encode())
        
        # Trailer
        pdf.write(b"trailer\n")
        pdf.write(f"<< /Size {len(obj_positions) + 1} /Root 1 0 R >>\n".encode())
        pdf.write(b"startxref\n")
        pdf.write(f"{xref_position}\n".encode())
        pdf.write(b"%%EOF\n")
        
        pdf.seek(0)
        return pdf
    
    def _escape_pdf_string(self, s):
        """Escape special characters in PDF strings."""
        if not s:
            return ""
        return s.replace('\\', '\\\\').replace('(', '\\(').replace(')', '\\)')
    
    def _extract_text_from_binary(self, data):
        """
        Extract readable text from binary file formats.
        This is a basic implementation that tries to find readable text.
        """
        result = []
        chunk_size = 1024
        for i in range(0, len(data), chunk_size):
            chunk = data[i:i+chunk_size]
            try:
                # Try to decode as text
                text = chunk.decode('utf-8', errors='replace')
                # Keep only printable characters
                text = ''.join(c for c in text if c.isprintable() or c in '\n\r\t')
                if text.strip():
                    result.append(text)
            except:
                pass
        
        if not result:
            return "Could not extract readable text from this document."
        
        return '\n'.join(result)
