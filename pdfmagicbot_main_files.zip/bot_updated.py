import os
import time
import json
import io
from datetime import datetime
import asyncio
import logging

# Configure logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Import telegram bot libs
from telegram import Update, Bot, InputFile
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, ContextTypes, filters

from config import (
    TOKEN, ADMIN_USERNAME, NOTIFICATION_CHANNEL_ID, MAX_FILE_SIZE,
    SUPPORTED_FORMATS, WELCOME_MESSAGE_EN, WELCOME_MESSAGE_AR,
    HELP_MESSAGE_EN, HELP_MESSAGE_AR, ABOUT_MESSAGE_EN, ABOUT_MESSAGE_AR
)
from pdf_converter import PDFConverter
from user_tracker import UserTracker

class PDFMagicBot:
    def __init__(self):
        """Initialize the PDF Magic Bot."""
        self.converter = PDFConverter()
        self.user_tracker = UserTracker()
        # Store user language preferences
        self.user_languages = {}
        self.bot = Bot(token=TOKEN)
        
        # Create application instance
        self.application = Application.builder().token(TOKEN).build()
        
        # Add handlers
        self.application.add_handler(CommandHandler("start", self.cmd_start))
        self.application.add_handler(CommandHandler("help", self.cmd_help))
        self.application.add_handler(CommandHandler("about", self.cmd_about))
        self.application.add_handler(CommandHandler("english", self.cmd_english))
        self.application.add_handler(CommandHandler("arabic", self.cmd_arabic))
        
        # Add document handler
        self.application.add_handler(MessageHandler(filters.PHOTO, self.handle_photo))
        self.application.add_handler(MessageHandler(filters.Document.ALL, self.handle_document))
        
        # Add callback query handler
        self.application.add_handler(CallbackQueryHandler(self.handle_callback_query))
        
        # Add error handler
        self.application.add_error_handler(self.error_handler)
        
        logger.info("PDF Magic Bot initialized")
    
    async def start(self):
        """Start the bot."""
        logger.info("Starting PDF Magic Bot...")
        await self.application.initialize()
        await self.application.start()
        await self.application.run_polling()
    
    def get_user_language(self, user_id):
        """Get the user's preferred language."""
        return self.user_languages.get(str(user_id), 'en')
    
    def set_user_language(self, user_id, language):
        """Set the user's preferred language."""
        self.user_languages[str(user_id)] = language
    
    async def send_message(self, chat_id, text, parse_mode=None):
        """Send a message to a chat."""
        try:
            await self.bot.send_message(
                chat_id=chat_id,
                text=text,
                parse_mode=parse_mode
            )
        except Exception as e:
            logger.error(f"Error sending message: {e}")
    
    async def cmd_start(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle the /start command."""
        user = update.effective_user
        user_id = user.id
        chat_id = update.effective_chat.id
        
        # Add user to tracker if new
        is_new_user = self.user_tracker.add_user(
            user_id=user_id,
            username=user.username,
            first_name=user.first_name,
            last_name=user.last_name
        )
        
        # Send notification for new users
        if is_new_user:
            try:
                await self.send_new_user_notification(user_id)
            except Exception as e:
                logger.error(f"Failed to send new user notification: {e}")
        
        # Get user language
        user_lang = self.get_user_language(user_id)
        
        # Send welcome message
        welcome_message = WELCOME_MESSAGE_AR if user_lang == 'ar' else WELCOME_MESSAGE_EN
        
        await self.send_message(
            chat_id=chat_id,
            text=welcome_message,
            parse_mode="Markdown"
        )
    
    async def cmd_help(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle the /help command."""
        user_id = update.effective_user.id
        chat_id = update.effective_chat.id
        
        # Get user language
        user_lang = self.get_user_language(user_id)
        
        # Send help message
        help_message = HELP_MESSAGE_AR if user_lang == 'ar' else HELP_MESSAGE_EN
        
        await self.send_message(
            chat_id=chat_id,
            text=help_message,
            parse_mode="Markdown"
        )
    
    async def cmd_about(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle the /about command."""
        user_id = update.effective_user.id
        chat_id = update.effective_chat.id
        
        # Get user language
        user_lang = self.get_user_language(user_id)
        
        # Send about message
        about_message = ABOUT_MESSAGE_AR if user_lang == 'ar' else ABOUT_MESSAGE_EN
        
        await self.send_message(
            chat_id=chat_id,
            text=about_message,
            parse_mode="Markdown"
        )
    
    async def cmd_english(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Switch to English language."""
        user_id = update.effective_user.id
        chat_id = update.effective_chat.id
        
        # Set user language to English
        self.set_user_language(user_id, 'en')
        
        # Confirm language change
        await self.send_message(
            chat_id=chat_id,
            text="🇬🇧 Language set to English!"
        )
    
    async def cmd_arabic(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Switch to Arabic language."""
        user_id = update.effective_user.id
        chat_id = update.effective_chat.id
        
        # Set user language to Arabic
        self.set_user_language(user_id, 'ar')
        
        # Confirm language change
        await self.send_message(
            chat_id=chat_id,
            text="🇸🇦 تم تغيير اللغة إلى العربية!"
        )
    
    async def handle_photo(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle photo messages."""
        user_id = update.effective_user.id
        chat_id = update.effective_chat.id
        user_lang = self.get_user_language(user_id)
        message = update.message
        
        # Get the photo file with highest resolution
        photo = message.photo[-1]
        
        # Log photo info
        logger.info(f"Received photo with file_id: {photo.file_id}, file_size: {photo.file_size}")
        
        # Check file size
        if photo.file_size > MAX_FILE_SIZE:
            size_error = "⚠️ الملف كبير جداً. الحد الأقصى هو 20 ميجابايت." if user_lang == 'ar' else "⚠️ File too large. Maximum size is 20MB."
            await self.send_message(chat_id=chat_id, text=size_error)
            return
        
        # Show processing message
        processing_msg = "جارٍ المعالجة..." if user_lang == 'ar' else "Processing..."
        status_message = await self.bot.send_message(chat_id=chat_id, text=processing_msg)
        
        try:
            # Get file
            file = await photo.get_file()
            
            # Download file content
            photo_content = await file.download_as_bytearray()
            
            # Generate a unique filename
            timestamp = int(time.time())
            photo_name = f"photo_{timestamp}.jpg"
            
            # Convert to PDF
            success, result = self.converter.convert_to_pdf(
                file_content=photo_content,
                filename=photo_name
            )
            
            if success:
                pdf_content, pdf_filename = result
                
                # Track this conversion
                self.user_tracker.record_conversion(user_id, 'jpg')
                
                # Create caption based on user's language
                caption = f"تم التحويل من {photo_name}" if user_lang == 'ar' else f"Converted from {photo_name}"
                
                # Log file details
                if hasattr(pdf_content, 'getbuffer'):
                    logger.info(f"PDF file size: {len(pdf_content.getbuffer())} bytes")
                
                # Create InputFile for Telegram
                if hasattr(pdf_content, 'getvalue'):
                    pdf_bytes = pdf_content.getvalue()
                    logger.info(f"Sending PDF with size: {len(pdf_bytes)} bytes")
                    pdf_file = InputFile(pdf_bytes, filename=pdf_filename)
                    
                    # Send the PDF
                    await self.bot.send_document(
                        chat_id=chat_id,
                        document=pdf_file,
                        caption=caption
                    )
                else:
                    raise Exception("PDF content is not in the expected format")
            else:
                # Error message varies by language
                error_text = f"⚠️ خطأ في التحويل: {result}" if user_lang == 'ar' else f"⚠️ Conversion error: {result}"
                await self.send_message(chat_id=chat_id, text=error_text)
            
            # Delete processing message
            await status_message.delete()
            
        except Exception as e:
            logger.error(f"Error processing photo: {e}", exc_info=True)
            error_text = "⚠️ حدث خطأ أثناء معالجة الصورة." if user_lang == 'ar' else "⚠️ Error processing the photo."
            await self.send_message(chat_id=chat_id, text=error_text)
            
            # Delete processing message if it still exists
            try:
                await status_message.delete()
            except:
                pass
    
    async def handle_document(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle document messages."""
        user_id = update.effective_user.id
        chat_id = update.effective_chat.id
        user_lang = self.get_user_language(user_id)
        document = update.message.document
        
        # Get file info
        file_name = document.file_name
        file_size = document.file_size
        mime_type = document.mime_type
        
        # Log document info
        logger.info(f"Received document: {file_name}, size: {file_size}, type: {mime_type}")
        
        # Extract file extension
        if file_name:
            file_ext = file_name.split('.')[-1].lower() if '.' in file_name else ''
        else:
            # Try to determine extension from MIME type
            if 'image/jpeg' in mime_type:
                file_ext = 'jpg'
            elif 'image/png' in mime_type:
                file_ext = 'png'
            elif 'text/plain' in mime_type:
                file_ext = 'txt'
            else:
                file_ext = ''
                
            # Create a basic file name if none provided
            timestamp = int(time.time())
            file_name = f"document_{timestamp}.{file_ext}" if file_ext else f"document_{timestamp}"
        
        # Check if file type is supported
        if file_ext not in SUPPORTED_FORMATS:
            unsupported_text = f"⚠️ نوع الملف غير مدعوم: .{file_ext}" if user_lang == 'ar' else f"⚠️ Unsupported file type: .{file_ext}"
            await self.send_message(chat_id=chat_id, text=unsupported_text)
            
            # Show supported formats
            formats_list = ", ".join(f".{ext}" for ext in SUPPORTED_FORMATS)
            formats_text = f"الأنواع المدعومة: {formats_list}" if user_lang == 'ar' else f"Supported formats: {formats_list}"
            await self.send_message(chat_id=chat_id, text=formats_text)
            return
        
        # Check file size
        if file_size > MAX_FILE_SIZE:
            size_error = "⚠️ الملف كبير جداً. الحد الأقصى هو 20 ميجابايت." if user_lang == 'ar' else "⚠️ File too large. Maximum size is 20MB."
            await self.send_message(chat_id=chat_id, text=size_error)
            return
        
        # Show processing message
        processing_msg = "جارٍ المعالجة..." if user_lang == 'ar' else "Processing..."
        status_message = await self.bot.send_message(chat_id=chat_id, text=processing_msg)
        
        try:
            # Get file
            file = await document.get_file()
            
            # Download file content
            file_content = await file.download_as_bytearray()
            
            # Convert to PDF
            success, result = self.converter.convert_to_pdf(
                file_content=file_content,
                filename=file_name
            )
            
            if success:
                pdf_content, pdf_filename = result
                
                # Track this conversion
                self.user_tracker.record_conversion(user_id, file_ext)
                
                # Create caption based on user's language
                caption = f"تم التحويل من {file_name}" if user_lang == 'ar' else f"Converted from {file_name}"
                
                # Log file details
                if hasattr(pdf_content, 'getbuffer'):
                    logger.info(f"PDF file size: {len(pdf_content.getbuffer())} bytes")
                
                # Create InputFile for Telegram
                if hasattr(pdf_content, 'getvalue'):
                    pdf_bytes = pdf_content.getvalue()
                    logger.info(f"Sending PDF with size: {len(pdf_bytes)} bytes")
                    pdf_file = InputFile(pdf_bytes, filename=pdf_filename)
                    
                    # Send the PDF
                    await self.bot.send_document(
                        chat_id=chat_id,
                        document=pdf_file,
                        caption=caption
                    )
                else:
                    raise Exception("PDF content is not in the expected format")
            else:
                # Error message varies by language
                error_text = f"⚠️ خطأ في التحويل: {result}" if user_lang == 'ar' else f"⚠️ Conversion error: {result}"
                await self.send_message(chat_id=chat_id, text=error_text)
            
            # Delete processing message
            await status_message.delete()
            
        except Exception as e:
            logger.error(f"Error processing document: {e}", exc_info=True)
            error_text = "⚠️ حدث خطأ أثناء معالجة المستند." if user_lang == 'ar' else "⚠️ Error processing the document."
            await self.send_message(chat_id=chat_id, text=error_text)
            
            # Delete processing message if it still exists
            try:
                await status_message.delete()
            except:
                pass
    
    async def handle_callback_query(self, update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle callback queries from inline keyboards."""
        query = update.callback_query
        await query.answer()
        
        # Here you would process the callback data
        # Currently no callback queries are implemented
    
    async def send_new_user_notification(self, user_id):
        """Send a notification to the admin channel about a new user."""
        if not NOTIFICATION_CHANNEL_ID:
            logger.warning("Notification channel ID is not set.")
            return
        
        try:
            # Get user information
            user_info = self.user_tracker.format_user_info(user_id)
            
            # Get stats
            stats = self.user_tracker.get_stats()
            
            # Create notification message
            message = (
                f"🆕 *مستخدم جديد انضم* | *New User Joined*\n\n"
                f"{user_info}\n\n"
                f"*إحصائيات حالية:* | *Current Statistics:*\n"
                f"إجمالي المستخدمين | Total Users: {stats['total_users']}\n"
                f"المستخدمين النشطين (7 أيام) | Active Users (7 days): {stats['active_users_7days']}\n"
                f"إجمالي التحويلات | Total Conversions: {stats['total_conversions']}"
            )
            
            # Debug log
            logger.info(f"Sending notification to channel: {NOTIFICATION_CHANNEL_ID}")
            
            # Send notification to channel
            await self.bot.send_message(
                chat_id=NOTIFICATION_CHANNEL_ID,
                text=message,
                parse_mode="Markdown"
            )
            
            logger.info("Successfully sent notification to channel")
            
        except Exception as e:
            logger.error(f"Error sending notification: {e}", exc_info=True)
    
    async def error_handler(self, update: object, context: ContextTypes.DEFAULT_TYPE):
        """Handle errors."""
        logger.error(f"Exception while handling an update: {context.error}", exc_info=context.error)

async def main():
    """Start the bot."""
    bot = PDFMagicBot()
    await bot.start()

if __name__ == "__main__":
    # Run the bot
    asyncio.run(main())