import asyncio
import nest_asyncio
import logging
from bot_updated import PDFMagicBot

# Configure logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Apply nest_asyncio to allow running asyncio in an already running event loop
nest_asyncio.apply()

async def start_bot():
    """Start the bot."""
    bot = PDFMagicBot()
    await bot.start()

if __name__ == "__main__":
    print("Starting PDF Magic Bot (Updated Version)...")
    try:
        # Get the current event loop
        loop = asyncio.get_event_loop()
        # Run the bot in the current event loop
        loop.run_until_complete(start_bot())
    except KeyboardInterrupt:
        print("Bot stopped.")
    except Exception as e:
        print(f"Error running bot: {e}")
        import traceback
        traceback.print_exc()