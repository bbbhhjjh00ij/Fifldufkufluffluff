#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import logging
import nest_asyncio
from datetime import datetime
import asyncio

# Import telegram libraries
from telegram import Bot, Update
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes

# Import config
from config import TOKEN, NOTIFICATION_CHANNEL_ID

# Configure logging
logging.basicConfig(
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    level=logging.INFO
)
logger = logging.getLogger(__name__)

# Apply nest_asyncio to handle nested event loops
nest_asyncio.apply()

# Define command handlers
async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Send a message when the command /start is issued."""
    user = update.effective_user
    await update.message.reply_text(f"مرحباً بك {user.first_name}! أنا بوت PDF Magic. يمكنك إرسال الصور أو المستندات وسأقوم بتحويلها إلى PDF.")
    
    # Send notification to the channel about a new user
    await send_notification(f"🆕 مستخدم جديد! {user.first_name} {user.last_name or ''} (@{user.username or 'بدون معرف'})")

async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Send a message when the command /help is issued."""
    await update.message.reply_text("أرسل صورة أو مستند وسأقوم بتحويله إلى PDF.")

async def send_notification(message):
    """Send a notification to the channel."""
    try:
        logger.info(f"Sending notification to channel: {NOTIFICATION_CHANNEL_ID}")
        logger.info(f"Message: {message}")
        
        # Create bot instance
        bot = Bot(TOKEN)
        
        # Send message to channel
        result = await bot.send_message(
            chat_id=NOTIFICATION_CHANNEL_ID,
            text=message,
            parse_mode="Markdown"
        )
        
        logger.info(f"Notification sent successfully: {result}")
        return True
    except Exception as e:
        logger.error(f"Error sending notification: {e}", exc_info=True)
        return False

async def test_notification():
    """Test sending a notification to the channel."""
    logger.info("Testing notification to channel...")
    message = f"""
🧪 *اختبار الإشعارات* | *Notification Test*

تم إرسال هذه الرسالة من بوت PDF Magic المطور الجديد باستخدام مكتبة python-telegram-bot.

This message was sent from the new PDF Magic Bot using the python-telegram-bot library.

⏱️ وقت الإرسال | Timestamp: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
"""
    
    success = await send_notification(message)
    if success:
        logger.info("✅ Notification test successful!")
    else:
        logger.error("❌ Notification test failed!")

async def main():
    """Start the bot."""
    # Create the Application
    application = Application.builder().token(TOKEN).build()
    
    # Add handlers
    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(CommandHandler("help", help_command))
    
    # Test sending a notification
    await test_notification()
    
    # Start the Bot
    await application.initialize()
    await application.start()
    await application.updater.start_polling()
    
    # Run the bot until the user presses Ctrl-C
    logger.info("Bot is running...")
    
    # Keep the application running
    while True:
        await asyncio.sleep(1)

if __name__ == '__main__':
    try:
        # Get event loop
        loop = asyncio.get_event_loop()
        # Run the main function
        loop.run_until_complete(main())
    except KeyboardInterrupt:
        logger.info("Bot stopped by user.")
    except Exception as e:
        logger.error(f"Error running bot: {e}", exc_info=True)