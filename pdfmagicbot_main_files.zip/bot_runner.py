import asyncio
from bot_updated import main

if __name__ == "__main__":
    # Run the bot using asyncio
    asyncio.run(main())