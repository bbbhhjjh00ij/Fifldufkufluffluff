import json
import os
import requests
import time
from urllib.parse import urlencode

class TelegramAPI:
    def __init__(self, token):
        """Initialize the Telegram API client with a bot token."""
        self.token = token
        self.base_url = f"https://api.telegram.org/bot{token}/"
        self.file_url = f"https://api.telegram.org/file/bot{token}/"
    
    def get_updates(self, offset=None, timeout=30):
        """Get updates from Telegram Bot API."""
        params = {'timeout': timeout}
        if offset:
            params['offset'] = offset
        
        url = self.base_url + 'getUpdates'
        try:
            response = requests.get(url, params=params)
            return response.json()
        except requests.exceptions.RequestException as e:
            print(f"Error getting updates: {e}")
            return {'ok': False, 'description': str(e)}
    
    def send_message(self, chat_id, text, parse_mode=None, reply_to_message_id=None):
        """Send a text message to a chat."""
        params = {
            'chat_id': chat_id,
            'text': text
        }
        
        if parse_mode:
            params['parse_mode'] = parse_mode
        
        if reply_to_message_id:
            params['reply_to_message_id'] = reply_to_message_id
        
        url = self.base_url + 'sendMessage'
        try:
            response = requests.post(url, json=params)
            return response.json()
        except requests.exceptions.RequestException as e:
            print(f"Error sending message: {e}")
            return {'ok': False, 'description': str(e)}
    
    def send_document(self, chat_id, document, caption=None, reply_to_message_id=None):
        """Send a document (file) to a chat."""
        url = self.base_url + 'sendDocument'
        
        params = {
            'chat_id': chat_id
        }
        
        if caption:
            params['caption'] = caption
        
        if reply_to_message_id:
            params['reply_to_message_id'] = reply_to_message_id
        
        # Prepare files parameter properly based on document type
        if isinstance(document, tuple) and len(document) == 3:
            # If document is a tuple of (filename, data, mime_type)
            filename, data, mime_type = document
            
            # Debug output for troubleshooting
            print(f"Sending document: {filename}, size: {len(data) if data else 0} bytes, type: {mime_type}")
            
            files = {
                'document': (filename, data, mime_type)
            }
        else:
            # If document is a simple value (like file_id)
            files = {
                'document': document
            }
        
        try:
            response = requests.post(url, data=params, files=files)
            result = response.json()
            
            # Debug output
            if not result.get('ok'):
                print(f"Error from Telegram API: {result}")
            
            return result
        except requests.exceptions.RequestException as e:
            print(f"Error sending document: {e}")
            return {'ok': False, 'description': str(e)}
    
    def get_file(self, file_id):
        """Get file information and path for a file on Telegram servers."""
        url = self.base_url + 'getFile'
        params = {'file_id': file_id}
        
        try:
            response = requests.get(url, params=params)
            result = response.json()
            if result.get('ok'):
                return result['result']
            return None
        except requests.exceptions.RequestException as e:
            print(f"Error getting file info: {e}")
            return None
    
    def download_file(self, file_path):
        """Download a file from Telegram servers."""
        url = self.file_url + file_path
        
        try:
            response = requests.get(url)
            return response.content
        except requests.exceptions.RequestException as e:
            print(f"Error downloading file: {e}")
            return None
    
    def answer_callback_query(self, callback_query_id, text=None, show_alert=False):
        """Answer a callback query from an inline keyboard button."""
        url = self.base_url + 'answerCallbackQuery'
        params = {'callback_query_id': callback_query_id}
        
        if text:
            params['text'] = text
        
        params['show_alert'] = show_alert
        
        try:
            response = requests.post(url, json=params)
            return response.json()
        except requests.exceptions.RequestException as e:
            print(f"Error answering callback query: {e}")
            return {'ok': False, 'description': str(e)}
