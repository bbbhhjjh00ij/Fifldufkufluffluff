"""
Script to send ALL files in the project directory to the admin.
"""
import os
import requests
import zipfile
import io
import time
import json

# Bot token (using the same as in the main bot)
TOKEN = "8034868736:AAGqs0nKmKnzx9o7XWEGa2M3p3hve4WlOk4"
ADMIN_ID = "7971415230"

def get_all_files(exclude_dirs=None):
    """Get a list of all files in the directory that are not in excluded directories."""
    if exclude_dirs is None:
        exclude_dirs = ['.git', '__pycache__', '.upm', '.config']
    
    all_files = []
    for root, dirs, files in os.walk('.'):
        # Skip excluded directories
        dirs[:] = [d for d in dirs if d not in exclude_dirs]
        
        for file in files:
            file_path = os.path.join(root, file)
            # Only include regular files (not symlinks, etc.)
            if os.path.isfile(file_path):
                all_files.append(file_path)
    
    return all_files

def create_complete_zip():
    """Create a ZIP file containing all project files."""
    all_files = get_all_files()
    
    # Create a zip file in memory
    zip_buffer = io.BytesIO()
    with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
        # Add all files
        for file_path in all_files:
            try:
                # Try to read as text first
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        content = f.read()
                    zip_file.writestr(file_path, content)
                except UnicodeDecodeError:
                    # If it fails, read as binary
                    with open(file_path, 'rb') as f:
                        zip_file.writestr(file_path, f.read())
            except Exception as e:
                print(f"Error adding {file_path}: {e}")
        
        # Create a file listing
        file_listing = "# All Project Files\n\n"
        for file_path in sorted(all_files):
            file_listing += f"- {file_path}\n"
        
        zip_file.writestr('ALL_FILES_LIST.md', file_listing)
        
        # Add a readme with project overview
        project_overview = """# PDF Magic Bot - Complete Project

## Overview
This is a Telegram bot that converts various file types to PDF format. It supports document files and images, and provides a seamless user experience in both Arabic and English.

## Key Features
- Convert various file types to PDF
- Support for multiple languages (Arabic and English)
- User tracking and statistics
- Admin notifications for new users
- Detailed error handling and logging
- User-friendly interface with command-less operation

## Complete File List
All files in the project are included in this ZIP archive. This includes:

1. **Core Bot Files**
   - bot.py: Main bot implementation using custom API
   - config.py: Configuration settings
   - pdf_converter.py: File conversion logic
   - telegram_api.py: Custom Telegram API implementation
   - user_tracker.py: User statistics tracking

2. **Alternative Implementations**
   - bot_updated.py: Implementation using python-telegram-bot library
   - simple_bot.py: Simplified implementation for testing
   - run_updated_bot.py: Runner for the updated bot version

3. **Data Files**
   - users.json: User database

4. **Project Configuration**
   - pyproject.toml: Python project configuration
   - replit.nix: Replit environment configuration

5. **Utility Scripts**
   - Various utility and notification scripts

## Installation and Usage
Please refer to the installation instructions included in the archive to set up and run the bot.

## Bot Token
The bot token is: 8034868736:AAGqs0nKmKnzx9o7XWEGa2M3p3hve4WlOk4

## Required Libraries
- reportlab: For PDF creation
- Pillow: For image processing
- PyPDF2: For PDF manipulation
- requests: For HTTP communication
- (Optional) python-telegram-bot: For alternative implementation
- (Optional) nest-asyncio: For running async code in certain environments
"""
        zip_file.writestr('PROJECT_OVERVIEW.md', project_overview)
    
    zip_buffer.seek(0)
    return zip_buffer.getvalue()

def send_all_files_as_document(admin_id):
    """Send all project files as a document to the admin."""
    url = f"https://api.telegram.org/bot{TOKEN}/sendDocument"
    
    # Create zip file
    zip_data = create_complete_zip()
    
    files = {
        'document': ('pdfmagicbot_complete_project.zip', zip_data, 'application/zip')
    }
    
    data = {
        'chat_id': admin_id,
        'caption': 'المشروع الكامل لبوت PDF Magic مع جميع الملفات\nComplete PDF Magic Bot project with ALL files'
    }
    
    print(f"Sending all files to admin ID: {admin_id}")
    response = requests.post(url, data=data, files=files)
    result = response.json()
    return result

def send_complete_description(admin_id):
    """Send a complete description of the project to the admin."""
    url = f"https://api.telegram.org/bot{TOKEN}/sendMessage"
    
    complete_message = """
🔍 *مشروع بوت PDF Magic الكامل* 🔍

تم إرسال ملف مضغوط يحتوي على جميع ملفات المشروع. هذا الملف يتضمن:

*1. ملفات البوت الأساسية:*
• bot.py: التطبيق الرئيسي للبوت باستخدام واجهة برمجة مخصصة
• config.py: إعدادات التكوين
• pdf_converter.py: منطق تحويل الملفات
• telegram_api.py: تطبيق واجهة برمجة تلغرام المخصصة
• user_tracker.py: تتبع إحصائيات المستخدم

*2. تطبيقات بديلة:*
• bot_updated.py: تطبيق باستخدام مكتبة python-telegram-bot
• simple_bot.py: تطبيق مبسط للاختبار
• run_updated_bot.py: مشغل لنسخة البوت المحدثة

*3. ملفات البيانات:*
• users.json: قاعدة بيانات المستخدم

*4. إعدادات المشروع:*
• pyproject.toml: إعدادات مشروع بايثون
• replit.nix: إعدادات بيئة Replit

*5. سكريبتات المساعدة:*
• سكريبتات متنوعة للإشعارات والمساعدة

*توكن البوت:*
8034868736:AAGqs0nKmKnzx9o7XWEGa2M3p3hve4WlOk4

*المكتبات المطلوبة:*
• reportlab: لإنشاء ملفات PDF
• Pillow: لمعالجة الصور
• PyPDF2: للتعامل مع ملفات PDF
• requests: للاتصال عبر HTTP
• (اختياري) python-telegram-bot: للتطبيق البديل
• (اختياري) nest-asyncio: لتشغيل الكود غير المتزامن في بيئات معينة

*لتشغيل البوت:*
1. تثبيت المكتبات المطلوبة
2. تعديل config.py لتعيين توكن البوت الخاص بك (إذا كنت تريد استخدام توكن مختلف)
3. تشغيل البوت: python bot.py
"""
    
    payload = {
        'chat_id': admin_id,
        'text': complete_message,
        'parse_mode': 'Markdown'
    }
    
    print(f"Sending complete description to admin ID: {admin_id}")
    response = requests.post(url, json=payload)
    result = response.json()
    
    if not result.get('ok', False):
        # Try again without markdown
        payload['parse_mode'] = None
        response = requests.post(url, json=payload)
        result = response.json()
    
    return result

if __name__ == "__main__":
    print(f"Sending all project files to admin: {ADMIN_ID}")
    
    # Send complete description first
    try:
        desc_result = send_complete_description(ADMIN_ID)
        if desc_result.get('ok', False):
            print("Successfully sent complete description!")
        else:
            print(f"Failed to send complete description: {desc_result.get('description', 'Unknown error')}")
    except Exception as e:
        print(f"Error sending complete description: {e}")
    
    # Brief pause between messages
    time.sleep(1)
    
    # Then send all files as document
    try:
        result = send_all_files_as_document(ADMIN_ID)
        if result.get('ok', False):
            print("Successfully sent all files as document!")
        else:
            print(f"Failed to send as document: {result.get('description', 'Unknown error')}")
    except Exception as e:
        print(f"Error sending document: {e}")