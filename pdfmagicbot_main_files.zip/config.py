import os

# Telegram bot token - get from environment variable
TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "8034868736:AAGqs0nKmKnzx9o7XWEGa2M3p3hve4WlOk4")

# Admin username for help command
ADMIN_USERNAME = "Bilalja0"

# Channel ID for notifications
# This should be a public or private channel ID where new user notifications will be sent
NOTIFICATION_CHANNEL_ID = "@PDFMagicBot7"  # Channel ID of the bot itself

# File size limit (in bytes) - 20MB is Telegram's default limit
MAX_FILE_SIZE = 20 * 1024 * 1024

# Supported file types for conversion
SUPPORTED_FORMATS = {
    # Text formats
    'txt': 'Text Document',
    'doc': 'Word Document',
    'docx': 'Word Document',
    'rtf': 'Rich Text Format',
    
    # Image formats
    'jpg': 'JPEG Image',
    'jpeg': 'JPEG Image',
    'png': 'PNG Image',
    'bmp': 'Bitmap Image',
    
    # Other formats
    'html': 'HTML Document',
    'md': 'Markdown Document',
}

# Welcome messages in different languages
WELCOME_MESSAGE_EN = """
🎉 *Welcome to PDF Magic Bot!* 🎉

This bot helps you convert various file types to PDF format easily.

*How to use:*
1. Simply send any supported file to this chat
2. The bot will convert it to PDF and send it back to you

*Supported file formats:*
• Text files (.txt)
• Images (.jpg, .jpeg, .png, .bmp)
• Documents (.doc, .docx, .rtf)
• Web formats (.html, .md)

*Rules:*
• Maximum file size: 20MB
• Be patient during conversion
• One file at a time

*Need help?*
Use the /help command to contact our admin for assistance.

*Language:*
• Use /english to switch to English
• استخدم الأمر /arabic للتحويل إلى اللغة العربية

*Commands:*
/start - Show this welcome message
/help - Get assistance from our admin
/about - Learn more about this bot

Enjoy using PDF Magic Bot! 📄✨
"""

WELCOME_MESSAGE_AR = """
🎉 *مرحبًا بك في بوت تحويل PDF!* 🎉

يساعدك هذا البوت على تحويل أنواع مختلفة من الملفات إلى تنسيق PDF بسهولة.

*كيفية الاستخدام:*
1. ما عليك سوى إرسال أي ملف مدعوم إلى هذه المحادثة
2. سيقوم البوت بتحويله إلى PDF وإرساله مرة أخرى إليك

*صيغ الملفات المدعومة:*
• ملفات نصية (.txt)
• صور (.jpg, .jpeg, .png, .bmp)
• مستندات (.doc, .docx, .rtf)
• تنسيقات ويب (.html, .md)

*القواعد:*
• الحد الأقصى لحجم الملف: 20 ميجابايت
• يرجى التحلي بالصبر أثناء التحويل
• ملف واحد في كل مرة

*بحاجة إلى مساعدة؟*
استخدم الأمر /help للتواصل مع المشرف للحصول على المساعدة.

*اللغة:*
• Use /english to switch to English
• استخدم الأمر /arabic للتحويل إلى اللغة العربية

*الأوامر:*
/start - عرض رسالة الترحيب هذه
/help - الحصول على مساعدة من المشرف
/about - تعرف أكثر على هذا البوت

استمتع باستخدام بوت تحويل PDF! 📄✨
"""

# Help messages in different languages
HELP_MESSAGE_EN = f"""
Need assistance? Contact our administrator @{ADMIN_USERNAME} with your question or issue.

Please provide details about any problems you're experiencing to help us assist you better.
"""

HELP_MESSAGE_AR = f"""
هل تحتاج إلى مساعدة؟ تواصل مع المشرف @{ADMIN_USERNAME} مع سؤالك أو المشكلة التي تواجهها.

يرجى تقديم تفاصيل حول أي مشاكل تواجهها لمساعدتنا في مساعدتك بشكل أفضل.
"""

# About messages in different languages
ABOUT_MESSAGE_EN = """
*PDF Magic Bot* 📄✨

A powerful Telegram bot that converts various file types to PDF format without requiring any external installations.

*Features:*
• Simple file conversion
• Multiple format support
• Fast processing
• Automatic language detection

*Version:* 1.1.0
*Developer:* @Bilalja0

Thank you for using PDF Magic Bot!
"""

ABOUT_MESSAGE_AR = """
*بوت تحويل PDF* 📄✨

بوت تلجرام قوي يحول أنواعًا مختلفة من الملفات إلى تنسيق PDF دون الحاجة إلى أي تثبيت خارجي.

*الميزات:*
• تحويل ملفات بسيط
• دعم تنسيقات متعددة
• معالجة سريعة
• اكتشاف اللغة تلقائيًا

*الإصدار:* 1.1.0
*المطور:* @Bilalja0

شكرًا لاستخدام بوت تحويل PDF!
"""

# Default to English for backward compatibility
WELCOME_MESSAGE = WELCOME_MESSAGE_EN
HELP_MESSAGE = HELP_MESSAGE_EN
ABOUT_MESSAGE = ABOUT_MESSAGE_EN
