"""
Script to send information about required libraries to the admin.
"""
import requests

# Bot token (using the same as in the main bot)
TOKEN = "8034868736:AAGqs0nKmKnzx9o7XWEGa2M3p3hve4WlOk4"
ADMIN_ID = "7971415230"

def send_library_information(admin_id):
    """Send detailed information about required libraries."""
    url = f"https://api.telegram.org/bot{TOKEN}/sendMessage"
    
    library_message = """
🔍 *المكتبات المطلوبة لبوت PDF Magic* 🔍

*المكتبات الأساسية:*
• reportlab==4.0.7 - لإنشاء وتعديل ملفات PDF
• Pillow==10.1.0 - لمعالجة الصور
• PyPDF2==3.0.1 - للعمليات على ملفات PDF
• requests==2.31.0 - لإرسال طلبات HTTP إلى واجهة برمجة تطبيقات تلغرام

*مكتبات اختيارية:*
• python-telegram-bot==20.7 - مكتبة بديلة لبوت تلغرام (مستخدمة في bot_updated.py)
• nest-asyncio==1.5.8 - لتشغيل الكود غير المتزامن في بيئات مثل Jupyter

*مكتبات قياسية في بايثون:*
• json, os, io, time, traceback, datetime, base64, zipfile, re

*أمر التثبيت:*
`pip install reportlab==4.0.7 Pillow==10.1.0 PyPDF2==3.0.1 requests==2.31.0`

*لتشغيل النسخة المحدثة من البوت (bot_updated.py):*
`pip install python-telegram-bot==20.7 nest-asyncio==1.5.8`

*توكن البوت:*
`8034868736:AAGqs0nKmKnzx9o7XWEGa2M3p3hve4WlOk4`

*ملفات المشروع الرئيسية:*
• bot.py: كود البوت الرئيسي
• config.py: إعدادات البوت
• pdf_converter.py: محول الملفات إلى PDF
• telegram_api.py: تطبيق واجهة برمجة تلغرام المخصص
• user_tracker.py: وظائف لتتبع إحصائيات المستخدم
"""
    
    payload = {
        'chat_id': admin_id,
        'text': library_message,
        'parse_mode': 'Markdown'
    }
    
    print(f"Sending library information to admin ID: {admin_id}")
    response = requests.post(url, json=payload)
    result = response.json()
    return result

if __name__ == "__main__":
    print(f"Sending library information to admin: {ADMIN_ID}")
    
    # Send library information
    try:
        lib_result = send_library_information(ADMIN_ID)
        if lib_result.get('ok', False):
            print("Successfully sent library information!")
        else:
            print(f"Failed to send library information: {lib_result.get('description', 'Unknown error')}")
            
            # Try again without markdown
            payload = {
                'chat_id': ADMIN_ID,
                'text': """
المكتبات المطلوبة لبوت PDF Magic:

المكتبات الأساسية:
• reportlab==4.0.7 - لإنشاء وتعديل ملفات PDF
• Pillow==10.1.0 - لمعالجة الصور
• PyPDF2==3.0.1 - للعمليات على ملفات PDF
• requests==2.31.0 - لإرسال طلبات HTTP إلى واجهة برمجة تطبيقات تلغرام

مكتبات اختيارية:
• python-telegram-bot==20.7 - مكتبة بديلة لبوت تلغرام (مستخدمة في bot_updated.py)
• nest-asyncio==1.5.8 - لتشغيل الكود غير المتزامن في بيئات مثل Jupyter

مكتبات قياسية في بايثون:
• json, os, io, time, traceback, datetime, base64, zipfile, re

أمر التثبيت:
pip install reportlab==4.0.7 Pillow==10.1.0 PyPDF2==3.0.1 requests==2.31.0

لتشغيل النسخة المحدثة من البوت (bot_updated.py):
pip install python-telegram-bot==20.7 nest-asyncio==1.5.8

توكن البوت:
8034868736:AAGqs0nKmKnzx9o7XWEGa2M3p3hve4WlOk4

ملفات المشروع الرئيسية:
• bot.py: كود البوت الرئيسي
• config.py: إعدادات البوت
• pdf_converter.py: محول الملفات إلى PDF
• telegram_api.py: تطبيق واجهة برمجة تلغرام المخصص
• user_tracker.py: وظائف لتتبع إحصائيات المستخدم
"""
            }
            
            url = f"https://api.telegram.org/bot{TOKEN}/sendMessage"
            response = requests.post(url, json=payload)
            second_result = response.json()
            
            if second_result.get('ok', False):
                print("Successfully sent library information without markdown!")
            else:
                print(f"Failed again: {second_result.get('description', 'Unknown error')}")
    except Exception as e:
        print(f"Error sending library information: {e}")