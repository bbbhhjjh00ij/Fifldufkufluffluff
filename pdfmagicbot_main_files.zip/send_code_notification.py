"""
Script to send a notification with the full bot code to the admin.
"""
import os
import requests
import zipfile
import io
import time

# Bot token (using the same as in the main bot)
TOKEN = "8034868736:AAGqs0nKmKnzx9o7XWEGa2M3p3hve4WlOk4"
ADMIN_ID = "7971415230"

def collect_code():
    """Collect all important Python code files."""
    files_to_send = [
        'bot.py',
        'config.py',
        'pdf_converter.py',
        'telegram_api.py',
        'user_tracker.py',
        'bot_updated.py',
        'simple_bot.py'
    ]
    
    # Create a zip file in memory
    zip_buffer = io.BytesIO()
    with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
        for filename in files_to_send:
            if os.path.exists(filename):
                with open(filename, 'r', encoding='utf-8') as f:
                    content = f.read()
                    zip_file.writestr(filename, content)
    
    zip_buffer.seek(0)
    return zip_buffer.getvalue()

def send_code_as_document(admin_id):
    """Send the code files as a document to the admin."""
    url = f"https://api.telegram.org/bot{TOKEN}/sendDocument"
    
    # Create zip file
    zip_data = collect_code()
    
    files = {
        'document': ('pdfmagicbot_code.zip', zip_data, 'application/zip')
    }
    
    data = {
        'chat_id': admin_id,
        'caption': 'الكود الكامل لبوت PDF Magic مع جميع الملفات الهامة\nComplete PDF Magic Bot code with all important files'
    }
    
    print(f"Sending code to admin ID: {admin_id}")
    response = requests.post(url, data=data, files=files)
    result = response.json()
    return result

def send_code_as_messages(admin_id):
    """Send each code file as a separate message."""
    url = f"https://api.telegram.org/bot{TOKEN}/sendMessage"
    
    files_to_send = [
        'bot.py',
        'config.py',
        'pdf_converter.py',
        'telegram_api.py',
        'user_tracker.py'
    ]
    
    results = []
    
    # First send introduction message
    intro_message = (
        "🔍 *كود بوت PDF Magic الكامل* 🔍\n\n"
        "فيما يلي الكود الكامل للبوت مع جميع المكتبات والتفاصيل المطلوبة.\n"
        "سيتم إرسال كل ملف في رسالة منفصلة.\n\n"
        "Bot token: `8034868736:AAGqs0nKmKnzx9o7XWEGa2M3p3hve4WlOk4`\n"
        "المكتبات المطلوبة:\n"
        "- `reportlab`: لإنشاء ملفات PDF\n"
        "- `Pillow`: لمعالجة الصور\n"
        "- `PyPDF2`: للتعامل مع ملفات PDF\n"
        "- `requests`: للاتصال بواجهة برمجة تطبيقات تلغرام\n\n"
        "سيتم إرسال الملفات في الرسائل التالية..."
    )
    
    payload = {
        'chat_id': admin_id,
        'text': intro_message,
        'parse_mode': 'Markdown'
    }
    
    response = requests.post(url, json=payload)
    results.append(response.json())
    time.sleep(1)  # To avoid rate limiting
    
    # Then send each file
    for filename in files_to_send:
        if os.path.exists(filename):
            with open(filename, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Prepare message with code
            message = f"📄 *{filename}*\n```python\n{content}\n```"
            
            # If message is too long, split it
            if len(message) > 4000:
                parts = [message[i:i+4000] for i in range(0, len(message), 4000)]
                for i, part in enumerate(parts):
                    payload = {
                        'chat_id': admin_id,
                        'text': f"Part {i+1}/{len(parts)} of {filename}\n{part}",
                        'parse_mode': 'Markdown'
                    }
                    response = requests.post(url, json=payload)
                    results.append(response.json())
                    time.sleep(1)  # To avoid rate limiting
            else:
                payload = {
                    'chat_id': admin_id,
                    'text': message,
                    'parse_mode': 'Markdown'
                }
                response = requests.post(url, json=payload)
                results.append(response.json())
                time.sleep(1)  # To avoid rate limiting
    
    # Send final summary
    summary = (
        "✅ *تم إرسال جميع ملفات الكود بنجاح* ✅\n\n"
        "الملفات المرسلة:\n"
        "- bot.py: البوت الرئيسي\n"
        "- config.py: إعدادات البوت\n"
        "- pdf_converter.py: محول الملفات إلى PDF\n"
        "- telegram_api.py: واجهة الاتصال بتلغرام\n"
        "- user_tracker.py: متتبع المستخدمين والإحصائيات\n\n"
        "شكرًا لاستخدام بوت PDF Magic! 🚀"
    )
    
    payload = {
        'chat_id': admin_id,
        'text': summary,
        'parse_mode': 'Markdown'
    }
    
    response = requests.post(url, json=payload)
    results.append(response.json())
    
    return results

if __name__ == "__main__":
    print(f"Sending code notification to admin: {ADMIN_ID}")
    
    # Try to send as document first (preferred method)
    try:
        result = send_code_as_document(ADMIN_ID)
        if result.get('ok', False):
            print("Successfully sent code as document!")
        else:
            print(f"Failed to send as document: {result.get('description', 'Unknown error')}")
            print("Trying to send as messages instead...")
            results = send_code_as_messages(ADMIN_ID)
            successful = sum(1 for r in results if r.get('ok', False))
            print(f"Sent {successful} of {len(results)} messages successfully")
    except Exception as e:
        print(f"Error sending document: {e}")
        print("Trying to send as messages instead...")
        try:
            results = send_code_as_messages(ADMIN_ID)
            successful = sum(1 for r in results if r.get('ok', False))
            print(f"Sent {successful} of {len(results)} messages successfully")
        except Exception as e2:
            print(f"Error sending messages: {e2}")