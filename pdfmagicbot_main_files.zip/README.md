# PDF Magic Bot - Complete Project Files

## Main Files:
- bot.py: Main bot implementation
- config.py: Configuration settings
- pdf_converter.py: File conversion logic
- telegram_api.py: Custom Telegram API
- user_tracker.py: User tracking functionality
- users.json: User database
- bot_updated.py: Updated bot version using python-telegram-bot library
- simple_bot.py: Simple test bot
- run_updated_bot.py: Runner for updated bot
- bot_runner.py: Bot runner utility

## Required Libraries:
- reportlab==4.0.7
- Pillow==10.1.0
- PyPDF2==3.0.1
- requests==2.31.0
- python-telegram-bot==20.7 (optional)
- nest-asyncio==1.5.8 (optional)

## Bot Token:
8034868736:AAGqs0nKmKnzx9o7XWEGa2M3p3hve4WlOk4

## Running the Bot:
1. Install required libraries: pip install reportlab==4.0.7 Pillow==10.1.0 PyPDF2==3.0.1 requests==2.31.0
2. Run the bot: python bot.py
