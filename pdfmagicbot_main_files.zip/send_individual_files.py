"""
Script to send all individual files one by one
"""
import os
import requests
import time

# Bot token
TOKEN = "8034868736:AAGqs0nKmKnzx9o7XWEGa2M3p3hve4WlOk4"
ADMIN_ID = "7971415230"

def send_file(admin_id, file_path):
    """Send a single file to the admin."""
    url = f"https://api.telegram.org/bot{TOKEN}/sendDocument"
    
    try:
        # Open the file
        with open(file_path, 'rb') as file:
            files = {'document': (os.path.basename(file_path), file)}
            data = {
                'chat_id': admin_id,
                'caption': f'File: {file_path}'
            }
            
            response = requests.post(url, data=data, files=files)
            result = response.json()
            
            if result.get('ok', False):
                print(f"Successfully sent {file_path}")
            else:
                print(f"Failed to send {file_path}: {result.get('description', 'Unknown error')}")
            
            return result
    except Exception as e:
        print(f"Error sending {file_path}: {e}")
        return None

def send_code_as_message(admin_id, file_path):
    """Send a code file as a text message."""
    url = f"https://api.telegram.org/bot{TOKEN}/sendMessage"
    
    try:
        # Read the file
        with open(file_path, 'r', encoding='utf-8') as file:
            content = file.read()
        
        # If the file is too large, just send a notification
        if len(content) > 4000:
            message = f"File {file_path} is too large to send as a message. It has been sent as a document."
            payload = {
                'chat_id': admin_id,
                'text': message
            }
            response = requests.post(url, json=payload)
            return response.json()
        
        # Otherwise send the content
        message = f"File: {file_path}\n\n```\n{content}\n```"
        payload = {
            'chat_id': admin_id,
            'text': message,
            'parse_mode': 'Markdown'
        }
        
        response = requests.post(url, json=payload)
        result = response.json()
        
        if not result.get('ok', False):
            # Try again without markdown
            payload['text'] = f"File: {file_path}\n\n{content}"
            payload['parse_mode'] = None
            response = requests.post(url, json=payload)
            result = response.json()
        
        return result
    except Exception as e:
        print(f"Error sending {file_path} as message: {e}")
        return None

def send_all_files_individually(admin_id):
    """Send all files one by one to the admin."""
    # Priority files to send first
    priority_files = [
        'bot.py',
        'config.py',
        'pdf_converter.py',
        'telegram_api.py',
        'user_tracker.py'
    ]
    
    # Send message that we're starting to send files
    url = f"https://api.telegram.org/bot{TOKEN}/sendMessage"
    start_message = {
        'chat_id': admin_id,
        'text': "سأبدأ بإرسال جميع ملفات المشروع واحدًا تلو الآخر. سيتم إرسال الملفات الرئيسية أولاً ثم الملفات الثانوية."
    }
    requests.post(url, json=start_message)
    
    # Send priority files first
    for file_path in priority_files:
        if os.path.exists(file_path):
            print(f"Sending file: {file_path}")
            send_file(admin_id, file_path)
            time.sleep(1)  # To avoid rate limiting
    
    # Then send all other files
    for root, dirs, files in os.walk('.'):
        # Skip some directories
        if any(excluded in root for excluded in ['__pycache__', '.git', '.upm', '.config']):
            continue
        
        for file in files:
            file_path = os.path.join(root, file)
            
            # Skip if it's a priority file (already sent) or a Python cache file
            if file_path in priority_files or file.endswith('.pyc'):
                continue
                
            if os.path.isfile(file_path):
                print(f"Sending file: {file_path}")
                send_file(admin_id, file_path)
                time.sleep(1)  # To avoid rate limiting
    
    # Send completion message
    complete_message = {
        'chat_id': admin_id,
        'text': "✅ تم إرسال جميع ملفات المشروع بنجاح! يمكنك الآن الحصول على الكود كاملاً لبوت PDF Magic."
    }
    requests.post(url, json=complete_message)

if __name__ == "__main__":
    print(f"Sending all files individually to admin: {ADMIN_ID}")
    send_all_files_individually(ADMIN_ID)