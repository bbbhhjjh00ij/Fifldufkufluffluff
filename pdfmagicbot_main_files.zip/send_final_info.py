"""
Script to send final information
"""
import requests

# Bot token
TOKEN = "8034868736:AAGqs0nKmKnzx9o7XWEGa2M3p3hve4WlOk4"
ADMIN_ID = "7971415230"

def send_message(admin_id, text):
    """Send a message to the admin."""
    url = f"https://api.telegram.org/bot{TOKEN}/sendMessage"
    payload = {'chat_id': admin_id, 'text': text}
    response = requests.post(url, json=payload)
    return response.json()

if __name__ == "__main__":
    # Send a final message with complete information
    final_message = """
✅ تم إرسال جميع ملفات بوت PDF Magic!

الملفات الرئيسية:
1. bot.py: كود البوت الرئيسي
2. config.py: إعدادات البوت
3. pdf_converter.py: محول الملفات إلى PDF
4. telegram_api.py: واجهة برمجة تطبيقات تلغرام
5. user_tracker.py: متتبع المستخدمين
6. users.json: قاعدة بيانات المستخدمين
7. bot_updated.py: نسخة محدثة من البوت
8. simple_bot.py: نسخة مبسطة من البوت
9. run_updated_bot.py: لتشغيل النسخة المحدثة
10. bot_runner.py: مشغل البوت

المكتبات المطلوبة:
• reportlab==4.0.7
• Pillow==10.1.0
• PyPDF2==3.0.1
• requests==2.31.0
• python-telegram-bot==20.7 (اختياري)
• nest-asyncio==1.5.8 (اختياري)

توكن البوت:
8034868736:AAGqs0nKmKnzx9o7XWEGa2M3p3hve4WlOk4

لتشغيل البوت:
1. قم بتثبيت المكتبات: pip install reportlab==4.0.7 Pillow==10.1.0 PyPDF2==3.0.1 requests==2.31.0
2. قم بتشغيل البوت: python bot.py

البوت يدعم:
• تحويل المستندات إلى PDF
• تحويل الصور إلى PDF
• اللغة العربية والإنجليزية
• تتبع المستخدمين والإحصائيات
• إرسال إشعارات إلى القناة

معلومات الاتصال بالمشرف المضبوطة في البوت:
• اسم المستخدم: Bilalja0
"""
    
    print(f"Sending final information to admin: {ADMIN_ID}")
    result = send_message(ADMIN_ID, final_message)
    print(f"Result: {result}")
    
    # Send a second message with file list summary
    file_list = """
ملخص الملفات المرسلة:

الملفات الرئيسية:
• bot.py
• config.py
• pdf_converter.py
• telegram_api.py
• user_tracker.py

الملفات الإضافية:
• bot_updated.py
• simple_bot.py
• run_updated_bot.py
• users.json
• bot_runner.py

ملفات التكوين:
• pyproject.toml
• replit.nix
• uv.lock

سكريبتات الإرسال:
• send_code_notification.py
• send_code_with_libraries.py
• send_essential_files.py
• send_individual_files.py
• send_libraries_only.py
• send_remaining_files.py
• send_simple_zip.py

التوكن: 8034868736:AAGqs0nKmKnzx9o7XWEGa2M3p3hve4WlOk4
"""
    
    print("Sending file list summary")
    result2 = send_message(ADMIN_ID, file_list)
    print(f"Result: {result2}")