"""
Script to send essential project files
"""
import os
import requests
import zipfile
import io

# Bot token
TOKEN = "8034868736:AAGqs0nKmKnzx9o7XWEGa2M3p3hve4WlOk4"
ADMIN_ID = "7971415230"

def create_zip():
    # List of essential files only
    essential_files = [
        'bot.py',
        'config.py',
        'pdf_converter.py',
        'telegram_api.py',
        'user_tracker.py',
        'bot_updated.py',
        'simple_bot.py',
        'run_updated_bot.py',
        'users.json',
        'bot_runner.py'
    ]
    
    # Create a zip file in memory
    zip_buffer = io.BytesIO()
    with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
        # Add only essential files
        for filename in essential_files:
            if os.path.exists(filename):
                try:
                    with open(filename, 'r', encoding='utf-8') as f:
                        content = f.read()
                    zip_file.writestr(filename, content)
                    print(f"Added {filename} to ZIP")
                except UnicodeDecodeError:
                    # If it fails, read as binary
                    with open(filename, 'rb') as f:
                        binary_content = f.read()
                    zip_file.writestr(filename, binary_content)
                    print(f"Added {filename} as binary to ZIP")
                except Exception as e:
                    print(f"Error adding {filename}: {e}")
    
        # Add a readme
        readme = """# PDF Magic Bot - Essential Files

## Files Included:
1. bot.py: Main bot implementation
2. config.py: Configuration settings
3. pdf_converter.py: File conversion logic
4. telegram_api.py: Custom Telegram API implementation
5. user_tracker.py: User statistics tracking
6. bot_updated.py: Alternative implementation using python-telegram-bot
7. simple_bot.py: Simplified implementation for testing
8. run_updated_bot.py: Runner for updated bot
9. users.json: User database
10. bot_runner.py: Bot runner utility

## Required Libraries:
- reportlab==4.0.7: For PDF creation
- Pillow==10.1.0: For image processing
- PyPDF2==3.0.1: For PDF operations
- requests==2.31.0: For HTTP requests
- python-telegram-bot==20.7 (optional): For alternative implementation
- nest-asyncio==1.5.8 (optional): For async code

## Bot Token:
8034868736:AAGqs0nKmKnzx9o7XWEGa2M3p3hve4WlOk4

## Running the Bot:
1. Install required libraries: pip install reportlab==4.0.7 Pillow==10.1.0 PyPDF2==3.0.1 requests==2.31.0
2. Run the bot: python bot.py
"""
        zip_file.writestr('README.md', readme)
        print("Added README.md to ZIP")
    
    zip_buffer.seek(0)
    return zip_buffer.getvalue()

def send_message(admin_id, text):
    url = f"https://api.telegram.org/bot{TOKEN}/sendMessage"
    payload = {'chat_id': admin_id, 'text': text}
    response = requests.post(url, json=payload)
    return response.json()

def send_zip(admin_id):
    url = f"https://api.telegram.org/bot{TOKEN}/sendDocument"
    
    # Create zip file
    zip_data = create_zip()
    
    files = {
        'document': ('pdfmagicbot_essential_files.zip', zip_data, 'application/zip')
    }
    
    data = {
        'chat_id': admin_id,
        'caption': 'الملفات الأساسية لبوت PDF Magic - Essential files for PDF Magic Bot with detailed README'
    }
    
    print(f"Sending to {admin_id}...")
    response = requests.post(url, data=data, files=files)
    print(f"Response: {response.status_code}")
    return response.json()

if __name__ == "__main__":
    print("Sending message about essential files...")
    message_text = """
الملفات الأساسية لبوت PDF Magic:

1. bot.py: تطبيق البوت الرئيسي
2. config.py: إعدادات التكوين
3. pdf_converter.py: منطق تحويل الملفات
4. telegram_api.py: تطبيق واجهة برمجة تلغرام المخصصة
5. user_tracker.py: تتبع إحصائيات المستخدم
6. bot_updated.py: تطبيق بديل باستخدام python-telegram-bot
7. simple_bot.py: تطبيق مبسط للاختبار
8. run_updated_bot.py: مشغل للبوت المحدث
9. users.json: قاعدة بيانات المستخدم
10. bot_runner.py: أداة تشغيل البوت

المكتبات المطلوبة:
- reportlab==4.0.7: لإنشاء PDF
- Pillow==10.1.0: لمعالجة الصور
- PyPDF2==3.0.1: لعمليات PDF
- requests==2.31.0: لطلبات HTTP
- python-telegram-bot==20.7 (اختياري): للتطبيق البديل
- nest-asyncio==1.5.8 (اختياري): للكود غير المتزامن

توكن البوت:
8034868736:AAGqs0nKmKnzx9o7XWEGa2M3p3hve4WlOk4

تشغيل البوت:
1. تثبيت المكتبات المطلوبة: pip install reportlab==4.0.7 Pillow==10.1.0 PyPDF2==3.0.1 requests==2.31.0
2. تشغيل البوت: python bot.py

سيتم إرسال الملفات في ملف مضغوط...
"""
    
    try:
        msg_result = send_message(ADMIN_ID, message_text)
        print(f"Message result: {msg_result}")
        
        print("Creating and sending ZIP with essential files...")
        result = send_zip(ADMIN_ID)
        print(f"Result: {result}")
    except Exception as e:
        print(f"Error: {e}")