import json
import os
import time
from datetime import datetime

class UserTracker:
    def __init__(self, storage_file='users.json'):
        """Initialize the user tracker with a storage file."""
        self.storage_file = storage_file
        self.users = self._load_users()
        
    def _load_users(self):
        """Load users from the storage file or create a new storage if it doesn't exist."""
        if os.path.exists(self.storage_file):
            try:
                with open(self.storage_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except (json.JSONDecodeError, FileNotFoundError):
                return {'users': {}, 'stats': {'total_users': 0, 'total_conversions': 0}}
        else:
            return {'users': {}, 'stats': {'total_users': 0, 'total_conversions': 0}}
    
    def _save_users(self):
        """Save users to the storage file."""
        with open(self.storage_file, 'w', encoding='utf-8') as f:
            json.dump(self.users, f, ensure_ascii=False, indent=2)
    
    def add_user(self, user_id, username=None, first_name=None, last_name=None):
        """Add a new user or update existing user information."""
        user_id = str(user_id)  # Convert to string for JSON storage
        is_new_user = user_id not in self.users['users']
        
        if is_new_user:
            self.users['stats']['total_users'] += 1
            
        # Update or create user information
        self.users['users'][user_id] = {
            'username': username or '',
            'first_name': first_name or '',
            'last_name': last_name or '',
            'join_date': self.users['users'].get(user_id, {}).get('join_date', datetime.now().strftime('%Y-%m-%d %H:%M:%S')),
            'last_active': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'conversions': self.users['users'].get(user_id, {}).get('conversions', 0)
        }
        
        self._save_users()
        return is_new_user
    
    def record_conversion(self, user_id, file_type):
        """Record a file conversion by a user."""
        user_id = str(user_id)
        if user_id in self.users['users']:
            self.users['users'][user_id]['conversions'] += 1
            self.users['users'][user_id]['last_active'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            self.users['stats']['total_conversions'] += 1
            self._save_users()
    
    def get_user_count(self):
        """Get the total number of users."""
        return self.users['stats']['total_users']
    
    def get_active_users(self, days=7):
        """Get the number of users active in the last X days."""
        active_count = 0
        current_time = time.time()
        for user_id, user_data in self.users['users'].items():
            last_active = datetime.strptime(user_data['last_active'], '%Y-%m-%d %H:%M:%S')
            last_active_timestamp = datetime.timestamp(last_active)
            if current_time - last_active_timestamp <= days * 24 * 60 * 60:
                active_count += 1
        return active_count
    
    def get_user_info(self, user_id):
        """Get information about a specific user."""
        user_id = str(user_id)
        return self.users['users'].get(user_id, None)
    
    def get_stats(self):
        """Get general statistics about bot usage."""
        stats = self.users['stats'].copy()
        stats['active_users_7days'] = self.get_active_users(7)
        stats['active_users_30days'] = self.get_active_users(30)
        return stats
    
    def format_user_info(self, user_id):
        """Format user information for notification messages."""
        user_id = str(user_id)
        user = self.get_user_info(user_id)
        if not user:
            return "مستخدم غير معروف | Unknown user"
        
        username = f"@{user['username']}" if user['username'] else "لا يوجد اسم مستخدم | No username"
        name = f"{user['first_name']} {user['last_name']}".strip()
        
        return (
            f"معرف المستخدم | User ID: {user_id}\n"
            f"الاسم | Name: {name}\n"
            f"اسم المستخدم | Username: {username}\n"
            f"تاريخ الانضمام | Joined: {user['join_date']}\n"
            f"عدد التحويلات | Conversions: {user['conversions']}"
        )
    
    def format_stats(self):
        """Format statistics for admin commands."""
        stats = self.get_stats()
        return (
            f"📊 *إحصائيات البوت | Bot Statistics*\n\n"
            f"إجمالي المستخدمين | Total Users: {stats['total_users']}\n"
            f"المستخدمين النشطين (7 أيام) | Active Users (7 days): {stats['active_users_7days']}\n"
            f"المستخدمين النشطين (30 يوم) | Active Users (30 days): {stats['active_users_30days']}\n"
            f"إجمالي التحويلات | Total Conversions: {stats['total_conversions']}"
        )
