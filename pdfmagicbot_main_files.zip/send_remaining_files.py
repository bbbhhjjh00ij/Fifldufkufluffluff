"""
Script to send remaining important files
"""
import os
import requests
import time

# Bot token
TOKEN = "8034868736:AAGqs0nKmKnzx9o7XWEGa2M3p3hve4WlOk4"
ADMIN_ID = "7971415230"

def send_file(admin_id, file_path):
    """Send a single file to the admin."""
    url = f"https://api.telegram.org/bot{TOKEN}/sendDocument"
    
    try:
        # Open the file
        with open(file_path, 'rb') as file:
            files = {'document': (os.path.basename(file_path), file)}
            data = {
                'chat_id': admin_id,
                'caption': f'File: {file_path}'
            }
            
            response = requests.post(url, data=data, files=files)
            result = response.json()
            
            if result.get('ok', False):
                print(f"Successfully sent {file_path}")
            else:
                print(f"Failed to send {file_path}: {result.get('description', 'Unknown error')}")
            
            return result
    except Exception as e:
        print(f"Error sending {file_path}: {e}")
        return None

if __name__ == "__main__":
    # List of remaining important files
    remaining_files = [
        'bot_updated.py',
        'simple_bot.py',
        'run_updated_bot.py',
        'users.json',
        'bot_runner.py',
        'pyproject.toml',
        'uv.lock'
    ]
    
    print(f"Sending remaining important files to admin: {ADMIN_ID}")
    
    # Send message that we're sending remaining files
    url = f"https://api.telegram.org/bot{TOKEN}/sendMessage"
    start_message = {
        'chat_id': ADMIN_ID,
        'text': "سأرسل الآن الملفات المتبقية المهمة للمشروع."
    }
    requests.post(url, json=start_message)
    
    # Send each file
    for file_path in remaining_files:
        if os.path.exists(file_path):
            print(f"Sending file: {file_path}")
            send_file(ADMIN_ID, file_path)
            time.sleep(1)  # To avoid rate limiting
    
    # Send completion message
    complete_message = {
        'chat_id': ADMIN_ID,
        'text': "✅ تم إرسال جميع الملفات المتبقية المهمة بنجاح!"
    }
    requests.post(url, json=complete_message)