"""
Simple script to send all files as a ZIP
"""
import os
import requests
import zipfile
import io

# Bot token
TOKEN = "8034868736:AAGqs0nKmKnzx9o7XWEGa2M3p3hve4WlOk4"
ADMIN_ID = "7971415230"

def create_zip():
    # Get all files excluding certain directories
    all_files = []
    exclude_dirs = ['.git', '__pycache__', '.upm', '.config']
    
    for root, dirs, files in os.walk('.'):
        # Skip excluded directories
        dirs[:] = [d for d in dirs if d not in exclude_dirs]
        
        for file in files:
            file_path = os.path.join(root, file)
            if os.path.isfile(file_path):
                all_files.append(file_path)
    
    # Create a zip file in memory
    zip_buffer = io.BytesIO()
    with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
        # Add all files
        for file_path in all_files:
            try:
                # Try to read as text first
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        content = f.read()
                    zip_file.writestr(file_path, content)
                except UnicodeDecodeError:
                    # If it fails, read as binary
                    with open(file_path, 'rb') as f:
                        zip_file.writestr(file_path, f.read())
            except Exception as e:
                print(f"Error adding {file_path}: {e}")
    
    zip_buffer.seek(0)
    return zip_buffer.getvalue()

def send_zip(admin_id):
    url = f"https://api.telegram.org/bot{TOKEN}/sendDocument"
    
    # Create zip file
    zip_data = create_zip()
    
    files = {
        'document': ('pdfmagicbot_all_files.zip', zip_data, 'application/zip')
    }
    
    data = {
        'chat_id': admin_id,
        'caption': 'جميع ملفات بوت PDF Magic - ALL files for PDF Magic Bot'
    }
    
    print(f"Sending to {admin_id}...")
    response = requests.post(url, data=data, files=files)
    print(f"Response: {response.status_code}")
    return response.json()

if __name__ == "__main__":
    print("Creating and sending ZIP with all files...")
    try:
        result = send_zip(ADMIN_ID)
        print(f"Result: {result}")
    except Exception as e:
        print(f"Error: {e}")