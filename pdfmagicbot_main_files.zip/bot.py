import os
import time
import json
import io
from datetime import datetime

from config import (
    TOKEN, ADMIN_USERNAME, NOTIFICATION_CHANNEL_ID, MAX_FILE_SIZE,
    SUPPORTED_FORMATS, WELCOME_MESSAGE_EN, WELCOME_MESSAGE_AR,
    HELP_MESSAGE_EN, HELP_MESSAGE_AR, ABOUT_MESSAGE_EN, ABOUT_MESSAGE_AR
)
from telegram_api import TelegramAPI
from pdf_converter import PDFConverter
from user_tracker import UserTracker

class PDFMagicBot:
    def __init__(self):
        """Initialize the PDF Magic Bot."""
        self.api = TelegramAPI(TOKEN)
        self.converter = PDFConverter()
        self.user_tracker = UserTracker()
        self.offset = None
        self.running = True
        # Store user language preferences
        self.user_languages = {}
    
    def start(self):
        """Start the bot and process incoming messages."""
        print(f"Starting PDF Magic Bot...")
        
        while self.running:
            try:
                # Get updates from Telegram
                updates = self.api.get_updates(offset=self.offset, timeout=30)
                
                if not updates.get('ok'):
                    print(f"Error getting updates: {updates.get('description')}")
                    time.sleep(5)
                    continue
                
                # Process each update
                for update in updates.get('result', []):
                    self.process_update(update)
                    # Update offset to acknowledge the update
                    self.offset = update['update_id'] + 1
            
            except KeyboardInterrupt:
                print("Bot stopped by user")
                self.running = False
            
            except Exception as e:
                print(f"Error in main loop: {e}")
                time.sleep(5)
    
    def process_update(self, update):
        """Process an update from Telegram."""
        try:
            # Process messages
            if 'message' in update:
                self.process_message(update['message'])
            
            # Process callback queries (for inline keyboards)
            elif 'callback_query' in update:
                self.process_callback_query(update['callback_query'])
        
        except Exception as e:
            print(f"Error processing update: {e}")
            # Try to notify the user about the error
            chat_id = None
            if 'message' in update:
                chat_id = update['message']['chat']['id']
            elif 'callback_query' in update:
                chat_id = update['callback_query']['message']['chat']['id']
            
            if chat_id:
                self.api.send_message(
                    chat_id=chat_id,
                    text="Sorry, an error occurred while processing your request. Please try again later."
                )
    
    def process_message(self, message):
        """Process a message sent to the bot."""
        chat_id = message['chat']['id']
        user_id = message['from']['id']
        username = message['from'].get('username', '')
        first_name = message['from'].get('first_name', '')
        last_name = message['from'].get('last_name', '')
        
        # Track the user
        is_new_user = self.user_tracker.add_user(user_id, username, first_name, last_name)
        
        # Check if this is a new user and send a notification
        if is_new_user:
            self.send_new_user_notification(user_id)
            # Send welcome message to new users (use English by default for new users)
            self.api.send_message(
                chat_id=chat_id,
                text=WELCOME_MESSAGE_EN,
                parse_mode="Markdown"
            )
            return
        
        # Get user's language preference (default to English)
        user_lang = self.user_languages.get(str(user_id), 'en')
        
        # Process commands
        if 'text' in message and message['text'].startswith('/'):
            self.process_command(message)
        
        # Process files
        elif 'document' in message:
            self.process_document(message)
        
        # Process photos
        elif 'photo' in message:
            self.process_photo(message)
        
        # Unknown message type
        else:
            unknown_msg = "يرجى إرسال ملف لتحويله إلى PDF. استخدم الأمر /start للحصول على التعليمات." if user_lang == 'ar' else "Please send a file to convert to PDF. Use /start for instructions."
            self.api.send_message(
                chat_id=chat_id,
                text=unknown_msg,
                parse_mode="Markdown"
            )
    
    def process_command(self, message):
        """Process a command sent to the bot."""
        chat_id = message['chat']['id']
        user_id = message['from']['id']
        username = message['from'].get('username', '')
        command = message['text'].split()[0].lower()
        
        # Get user's language preference (default to English)
        user_lang = self.user_languages.get(str(user_id), 'en')
        
        if command == '/start':
            # Send welcome message based on user's language
            welcome_msg = WELCOME_MESSAGE_AR if user_lang == 'ar' else WELCOME_MESSAGE_EN
            self.api.send_message(
                chat_id=chat_id,
                text=welcome_msg,
                parse_mode="Markdown"
            )
        
        elif command == '/help':
            # Send help message based on user's language
            help_msg = HELP_MESSAGE_AR if user_lang == 'ar' else HELP_MESSAGE_EN
            self.api.send_message(
                chat_id=chat_id,
                text=help_msg,
                parse_mode="Markdown"
            )
        
        elif command == '/about':
            # Send about message based on user's language
            about_msg = ABOUT_MESSAGE_AR if user_lang == 'ar' else ABOUT_MESSAGE_EN
            self.api.send_message(
                chat_id=chat_id,
                text=about_msg,
                parse_mode="Markdown"
            )
            
        elif command == '/english':
            # Switch to English
            self.user_languages[str(user_id)] = 'en'
            self.api.send_message(
                chat_id=chat_id,
                text="Language switched to English! 🇬🇧",
                parse_mode="Markdown"
            )
            
        elif command == '/arabic':
            # Switch to Arabic
            self.user_languages[str(user_id)] = 'ar'
            self.api.send_message(
                chat_id=chat_id,
                text="تم تغيير اللغة إلى العربية! 🇸🇦",
                parse_mode="Markdown"
            )
        
        elif command == '/stats' and username == ADMIN_USERNAME:
            # Admin-only command for statistics
            stats = self.user_tracker.format_stats()
            self.api.send_message(
                chat_id=chat_id,
                text=stats,
                parse_mode="Markdown"
            )
        
        else:
            # Unknown command message based on user's language
            unknown_cmd_msg = "أمر غير معروف. استخدم /start للحصول على التعليمات." if user_lang == 'ar' else "Unknown command. Use /start for instructions."
            self.api.send_message(
                chat_id=chat_id,
                text=unknown_cmd_msg,
                parse_mode="Markdown"
            )
    
    def process_document(self, message):
        """Process a document sent to the bot."""
        chat_id = message['chat']['id']
        user_id = message['from']['id']
        document = message['document']
        file_id = document['file_id']
        file_name = document.get('file_name', 'document.file')
        file_size = document.get('file_size', 0)
        
        # Get user's language preference
        user_lang = self.user_languages.get(str(user_id), 'en')
        
        # Check file size
        if file_size > MAX_FILE_SIZE:
            file_size_msg = f"الملف كبير جدًا. الحد الأقصى لحجم الملف هو {MAX_FILE_SIZE / (1024 * 1024):.1f} ميجابايت." if user_lang == 'ar' else f"File is too large. Maximum file size is {MAX_FILE_SIZE / (1024 * 1024):.1f}MB."
            self.api.send_message(
                chat_id=chat_id,
                text=file_size_msg,
                parse_mode="Markdown"
            )
            return
        
        # Check if file format is supported
        file_ext = os.path.splitext(file_name)[1].lower().strip('.')
        if file_ext not in SUPPORTED_FORMATS:
            unsupported_format_msg = f"تنسيق ملف غير مدعوم: .{file_ext}\n\nالتنسيقات المدعومة: {', '.join(SUPPORTED_FORMATS.keys())}" if user_lang == 'ar' else f"Unsupported file format: .{file_ext}\n\nSupported formats: {', '.join(SUPPORTED_FORMATS.keys())}"
            self.api.send_message(
                chat_id=chat_id,
                text=unsupported_format_msg,
                parse_mode="Markdown"
            )
            return
        
        # Send processing message
        processing_msg = f"جاري معالجة {SUPPORTED_FORMATS.get(file_ext, 'ملف')} الخاص بك..." if user_lang == 'ar' else f"Processing your {SUPPORTED_FORMATS.get(file_ext, 'file')}..."
        self.api.send_message(
            chat_id=chat_id,
            text=processing_msg,
            parse_mode="Markdown"
        )
        
        # Download file
        file_info = self.api.get_file(file_id)
        if not file_info or 'file_path' not in file_info:
            download_error_msg = "تعذر تنزيل الملف. يرجى المحاولة مرة أخرى." if user_lang == 'ar' else "Could not download the file. Please try again."
            self.api.send_message(
                chat_id=chat_id,
                text=download_error_msg,
                parse_mode="Markdown"
            )
            return
        
        file_content = self.api.download_file(file_info['file_path'])
        if not file_content:
            download_error_msg = "تعذر تنزيل الملف. يرجى المحاولة مرة أخرى." if user_lang == 'ar' else "Could not download the file. Please try again."
            self.api.send_message(
                chat_id=chat_id,
                text=download_error_msg,
                parse_mode="Markdown"
            )
            return
        
        # Convert to PDF
        success, result = self.converter.convert_to_pdf(file_content, file_name)
        
        if success:
            pdf_content, pdf_filename = result
            
            # Track this conversion
            self.user_tracker.record_conversion(user_id, file_ext)
            
            try:
                # Send the PDF
                if hasattr(pdf_content, 'seek'):
                    pdf_content.seek(0)
                    # Read the PDF content 
                    pdf_data = pdf_content.read()
                else:
                    # For compatibility with string type
                    pdf_data = pdf_content
                
                # Create caption based on user's language
                caption = f"تم التحويل من {file_name}" if user_lang == 'ar' else f"Converted from {file_name}"
                result = self.api.send_document(
                    chat_id=chat_id,
                    document=(pdf_filename, pdf_data, 'application/pdf'),
                    caption=caption
                )
                
                # Log the result for debugging
                if not result.get('ok', False):
                    error_desc = result.get('description', 'Unknown error')
                    print(f"Failed to send document: {error_desc}")
            except Exception as e:
                print(f"Error when sending PDF: {e}")
                error_msg = "عذراً، حدث خطأ أثناء إرسال الملف. يرجى المحاولة مرة أخرى." if user_lang == 'ar' else "Sorry, an error occurred while sending the file. Please try again."
                self.api.send_message(
                    chat_id=chat_id,
                    text=error_msg,
                    parse_mode="Markdown"
                )
        else:
            # Conversion failed
            failed_msg = f"فشل تحويل الملف: {result}" if user_lang == 'ar' else f"Failed to convert file: {result}"
            self.api.send_message(
                chat_id=chat_id,
                text=failed_msg,
                parse_mode="Markdown"
            )
    
    def process_photo(self, message):
        """Process a photo sent to the bot."""
        chat_id = message['chat']['id']
        user_id = message['from']['id']
        
        # Get user's language preference
        user_lang = self.user_languages.get(str(user_id), 'en')
        
        # Get the largest photo (last in the list)
        photo = message['photo'][-1]
        file_id = photo['file_id']
        
        # Generate a name for the photo
        file_name = f"photo_{int(time.time())}.jpg"
        
        # Send processing message
        processing_msg = "جاري معالجة صورتك..." if user_lang == 'ar' else "Processing your photo..."
        self.api.send_message(
            chat_id=chat_id,
            text=processing_msg,
            parse_mode="Markdown"
        )
        
        # Download file
        file_info = self.api.get_file(file_id)
        if not file_info or 'file_path' not in file_info:
            download_error_msg = "تعذر تنزيل الصورة. يرجى المحاولة مرة أخرى." if user_lang == 'ar' else "Could not download the photo. Please try again."
            self.api.send_message(
                chat_id=chat_id,
                text=download_error_msg,
                parse_mode="Markdown"
            )
            return
        
        file_content = self.api.download_file(file_info['file_path'])
        if not file_content:
            download_error_msg = "تعذر تنزيل الصورة. يرجى المحاولة مرة أخرى." if user_lang == 'ar' else "Could not download the photo. Please try again."
            self.api.send_message(
                chat_id=chat_id,
                text=download_error_msg,
                parse_mode="Markdown"
            )
            return
        
        # Convert to PDF
        success, result = self.converter.convert_to_pdf(file_content, file_name)
        
        if success:
            pdf_content, pdf_filename = result
            
            # Track this conversion
            self.user_tracker.record_conversion(user_id, 'jpg')
            
            try:
                # Send the PDF
                if hasattr(pdf_content, 'seek'):
                    pdf_content.seek(0)
                    # Read the PDF content 
                    pdf_data = pdf_content.read()
                else:
                    # For compatibility with string type
                    pdf_data = pdf_content
                
                # Create caption based on user's language
                caption = "تم التحويل من صورة" if user_lang == 'ar' else "Converted from photo"
                result = self.api.send_document(
                    chat_id=chat_id,
                    document=(pdf_filename, pdf_data, 'application/pdf'),
                    caption=caption
                )
                
                # Log the result for debugging
                if not result.get('ok', False):
                    error_desc = result.get('description', 'Unknown error')
                    print(f"Failed to send photo document: {error_desc}")
            except Exception as e:
                print(f"Error when sending photo PDF: {e}")
                error_msg = "عذراً، حدث خطأ أثناء إرسال الملف. يرجى المحاولة مرة أخرى." if user_lang == 'ar' else "Sorry, an error occurred while sending the file. Please try again."
                self.api.send_message(
                    chat_id=chat_id,
                    text=error_msg,
                    parse_mode="Markdown"
                )
        else:
            # Conversion failed
            failed_msg = f"فشل تحويل الصورة: {result}" if user_lang == 'ar' else f"Failed to convert photo: {result}"
            self.api.send_message(
                chat_id=chat_id,
                text=failed_msg,
                parse_mode="Markdown"
            )
    
    def process_callback_query(self, callback_query):
        """Process a callback query from an inline keyboard button."""
        callback_data = callback_query.get('data', '')
        callback_id = callback_query['id']
        
        # Acknowledge the callback query
        self.api.answer_callback_query(callback_id)
        
        # Process the callback data
        # (Currently no callback queries are implemented)
    
    def send_new_user_notification(self, user_id):
        """Send a notification to the admin channel about a new user."""
        import requests
        
        if not NOTIFICATION_CHANNEL_ID:
            print("Notification channel ID is not set.")
            return
        
        try:
            # Get user information
            user_info = self.user_tracker.format_user_info(user_id)
            
            # Get stats
            stats = self.user_tracker.get_stats()
            
            # Create notification message
            message = (
                f"🆕 *مستخدم جديد انضم* | *New User Joined*\n\n"
                f"{user_info}\n\n"
                f"*إحصائيات حالية:* | *Current Statistics:*\n"
                f"إجمالي المستخدمين | Total Users: {stats['total_users']}\n"
                f"المستخدمين النشطين (7 أيام) | Active Users (7 days): {stats['active_users_7days']}\n"
                f"إجمالي التحويلات | Total Conversions: {stats['total_conversions']}"
            )
            
            # Debug log for channel ID
            print(f"Sending notification to channel: {NOTIFICATION_CHANNEL_ID}")
            
            # Send directly using requests - this is more reliable for channel usernames (@channel)
            url = f"https://api.telegram.org/bot{TOKEN}/sendMessage"
            payload = {
                'chat_id': NOTIFICATION_CHANNEL_ID,
                'text': message,
                'parse_mode': 'Markdown'
            }
            
            print(f"URL: {url}")
            print(f"Payload: {payload}")
            
            # Send the request
            response = requests.post(url, json=payload)
            
            # Parse the response
            result = response.json()
            
            # Log the result for debugging
            print(f"Notification API response: {result}")
            
            if not result.get('ok', False):
                error_desc = result.get('description', 'Unknown error')
                print(f"Failed to send notification: {error_desc}")
            else:
                print(f"Successfully sent notification to {NOTIFICATION_CHANNEL_ID}")
        
        except Exception as e:
            print(f"Error sending new user notification: {e}")
            import traceback
            traceback.print_exc()


if __name__ == "__main__":
    bot = PDFMagicBot()
    bot.start()
