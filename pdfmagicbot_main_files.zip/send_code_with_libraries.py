"""
Script to send a notification with the full bot code and required libraries to the admin.
"""
import os
import requests
import zipfile
import io
import time
import json

# Bot token (using the same as in the main bot)
TOKEN = "8034868736:AAGqs0nKmKnzx9o7XWEGa2M3p3hve4WlOk4"
ADMIN_ID = "7971415230"

def collect_code():
    """Collect all important Python code files."""
    files_to_send = [
        'bot.py',
        'config.py',
        'pdf_converter.py',
        'telegram_api.py',
        'user_tracker.py',
        'bot_updated.py',
        'simple_bot.py'
    ]
    
    # Create a zip file in memory
    zip_buffer = io.BytesIO()
    with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
        # Add all Python files
        for filename in files_to_send:
            if os.path.exists(filename):
                with open(filename, 'r', encoding='utf-8') as f:
                    content = f.read()
                    zip_file.writestr(filename, content)
        
        # Create requirements.txt file
        requirements = """
# Core libraries for PDF Magic Bot
reportlab==4.0.7      # For PDF creation and manipulation
Pillow==10.1.0        # For image processing
PyPDF2==3.0.1         # For PDF file operations
python-telegram-bot==20.7  # For Telegram bot API (optional, for bot_updated.py)
requests==2.31.0      # For HTTP requests
nest-asyncio==1.5.8   # For running async code in Jupyter (optional)

# Additional libraries used in the bot
json               # Standard library
os                 # Standard library
io                 # Standard library
time               # Standard library
traceback          # Standard library
datetime           # Standard library
base64             # Standard library
zipfile            # Standard library
re                 # Standard library
"""
        zip_file.writestr('requirements.txt', requirements)
        
        # Create installation guide
        installation_guide = """
# PDF Magic Bot - Installation Guide

## Prerequisites
- Python 3.7 or higher
- pip (Python package installer)

## Installation Steps

1. Create a virtual environment (optional but recommended):
   ```
   python -m venv pdfbot_env
   source pdfbot_env/bin/activate  # On Windows: pdfbot_env\\Scripts\\activate
   ```

2. Install the required packages:
   ```
   pip install -r requirements.txt
   ```

3. Configure the bot:
   - Edit `config.py` to set your Telegram bot token
   - Set the notification channel ID if you want to receive notifications

4. Run the bot:
   ```
   python bot.py
   ```

## Libraries and Their Purpose

- **reportlab**: Used for creating PDF documents from scratch
- **Pillow**: For image processing and manipulation
- **PyPDF2**: For working with existing PDF files
- **requests**: For making HTTP requests to the Telegram API
- **python-telegram-bot**: An optional, more advanced library for Telegram bots (used in bot_updated.py)
- **nest-asyncio**: Required when running async code in environments like Jupyter notebooks

## Files Description

- **bot.py**: Main bot code using the custom API implementation
- **config.py**: Configuration settings for the bot
- **pdf_converter.py**: Functions to convert various file formats to PDF
- **telegram_api.py**: Custom Telegram API client implementation
- **user_tracker.py**: Functions to track user statistics
- **bot_updated.py**: Alternative implementation using the python-telegram-bot library
- **simple_bot.py**: A simplified version for testing
- **users.json**: Database file for storing user information

## Telegram Bot Creation Steps

1. Talk to [@BotFather](https://t.me/botfather) on Telegram
2. Send /newbot and follow the instructions
3. Copy the token provided by BotFather
4. Paste the token in config.py

"""
        zip_file.writestr('INSTALLATION_GUIDE.md', installation_guide)
        
        # Create a JSON file with library versions
        library_info = {
            "required_libraries": [
                {
                    "name": "reportlab",
                    "version": "4.0.7",
                    "purpose": "PDF creation and manipulation",
                    "installation": "pip install reportlab==4.0.7"
                },
                {
                    "name": "Pillow",
                    "version": "10.1.0",
                    "purpose": "Image processing and manipulation",
                    "installation": "pip install Pillow==10.1.0"
                },
                {
                    "name": "PyPDF2",
                    "version": "3.0.1",
                    "purpose": "PDF file operations",
                    "installation": "pip install PyPDF2==3.0.1"
                },
                {
                    "name": "requests",
                    "version": "2.31.0",
                    "purpose": "HTTP requests to Telegram API",
                    "installation": "pip install requests==2.31.0"
                }
            ],
            "optional_libraries": [
                {
                    "name": "python-telegram-bot",
                    "version": "20.7",
                    "purpose": "Alternative Telegram bot library (for bot_updated.py)",
                    "installation": "pip install python-telegram-bot==20.7"
                },
                {
                    "name": "nest-asyncio",
                    "version": "1.5.8",
                    "purpose": "For running async code in Jupyter",
                    "installation": "pip install nest-asyncio==1.5.8"
                }
            ],
            "standard_libraries": [
                "json", "os", "io", "time", "traceback", 
                "datetime", "base64", "zipfile", "re"
            ]
        }
        zip_file.writestr('libraries.json', json.dumps(library_info, indent=2, ensure_ascii=False))
    
    zip_buffer.seek(0)
    return zip_buffer.getvalue()

def send_code_as_document(admin_id):
    """Send the code files as a document to the admin."""
    url = f"https://api.telegram.org/bot{TOKEN}/sendDocument"
    
    # Create zip file
    zip_data = collect_code()
    
    files = {
        'document': ('pdfmagicbot_code_with_libraries.zip', zip_data, 'application/zip')
    }
    
    data = {
        'chat_id': admin_id,
        'caption': 'الكود الكامل لبوت PDF Magic مع جميع المكتبات المطلوبة والتوثيق\nComplete PDF Magic Bot code with all required libraries and documentation'
    }
    
    print(f"Sending code with libraries to admin ID: {admin_id}")
    response = requests.post(url, data=data, files=files)
    result = response.json()
    return result

def send_library_information(admin_id):
    """Send detailed information about required libraries."""
    url = f"https://api.telegram.org/bot{TOKEN}/sendMessage"
    
    library_message = """
🔍 *المكتبات المطلوبة لبوت PDF Magic* 🔍

*المكتبات الأساسية:*
• `reportlab==4.0.7` - لإنشاء وتعديل ملفات PDF
• `Pillow==10.1.0` - لمعالجة الصور
• `PyPDF2==3.0.1` - للعمليات على ملفات PDF
• `requests==2.31.0` - لإرسال طلبات HTTP إلى واجهة برمجة تطبيقات تلغرام

*مكتبات اختيارية:*
• `python-telegram-bot==20.7` - مكتبة بديلة لبوت تلغرام (مستخدمة في bot_updated.py)
• `nest-asyncio==1.5.8` - لتشغيل الكود غير المتزامن في بيئات مثل Jupyter

*مكتبات قياسية في بايثون:*
• json, os, io, time, traceback, datetime, base64, zipfile, re

*أمر التثبيت:*
```
pip install reportlab==4.0.7 Pillow==10.1.0 PyPDF2==3.0.1 requests==2.31.0
```

*لتشغيل النسخة المحدثة من البوت (bot_updated.py):*
```
pip install python-telegram-bot==20.7 nest-asyncio==1.5.8
```

*توكن البوت:*
`8034868736:AAGqs0nKmKnzx9o7XWEGa2M3p3hve4WlOk4`

*ملفات المشروع الرئيسية:*
• `bot.py`: كود البوت الرئيسي
• `config.py`: إعدادات البوت
• `pdf_converter.py`: محول الملفات إلى PDF
• `telegram_api.py`: تطبيق واجهة برمجة تلغرام المخصص
• `user_tracker.py`: وظائف لتتبع إحصائيات المستخدم
"""
    
    payload = {
        'chat_id': admin_id,
        'text': library_message,
        'parse_mode': 'Markdown'
    }
    
    print(f"Sending library information to admin ID: {admin_id}")
    response = requests.post(url, json=payload)
    result = response.json()
    return result

if __name__ == "__main__":
    print(f"Sending code and library information to admin: {ADMIN_ID}")
    
    # Send library information first
    try:
        lib_result = send_library_information(ADMIN_ID)
        if lib_result.get('ok', False):
            print("Successfully sent library information!")
        else:
            print(f"Failed to send library information: {lib_result.get('description', 'Unknown error')}")
    except Exception as e:
        print(f"Error sending library information: {e}")
    
    # Brief pause between messages
    time.sleep(1)
    
    # Then send code as document
    try:
        result = send_code_as_document(ADMIN_ID)
        if result.get('ok', False):
            print("Successfully sent code as document with libraries!")
        else:
            print(f"Failed to send as document: {result.get('description', 'Unknown error')}")
    except Exception as e:
        print(f"Error sending document: {e}")