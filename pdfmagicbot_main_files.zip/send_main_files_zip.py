"""
Script to send only the main files in the root directory
"""
import os
import requests
import zipfile
import io

# Bot token
TOKEN = "8034868736:AAGqs0nKmKnzx9o7XWEGa2M3p3hve4WlOk4"
ADMIN_ID = "7971415230"

def create_zip_of_main_files():
    """Create a zip file containing only the main Python files in the root directory"""
    # Create a list of all files in the root directory
    root_files = [f for f in os.listdir('.') if os.path.isfile(f)]
    
    # Filter to only include Python files and important configuration files
    important_extensions = ['.py', '.json', '.toml', '.nix', '.md', '.lock']
    main_files = [f for f in root_files if any(f.endswith(ext) for ext in important_extensions)]
    
    # Create a zip file in memory
    zip_buffer = io.BytesIO()
    with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
        # Add each main file to the zip
        for filename in main_files:
            try:
                with open(filename, 'rb') as f:
                    zip_file.writestr(filename, f.read())
                print(f"Added {filename} to ZIP")
            except Exception as e:
                print(f"Error adding {filename}: {e}")
        
        # Add a README
        readme = """# PDF Magic Bot - Complete Project Files

## Main Files:
- bot.py: Main bot implementation
- config.py: Configuration settings
- pdf_converter.py: File conversion logic
- telegram_api.py: Custom Telegram API
- user_tracker.py: User tracking functionality
- users.json: User database
- bot_updated.py: Updated bot version using python-telegram-bot library
- simple_bot.py: Simple test bot
- run_updated_bot.py: Runner for updated bot
- bot_runner.py: Bot runner utility

## Required Libraries:
- reportlab==4.0.7
- Pillow==10.1.0
- PyPDF2==3.0.1
- requests==2.31.0
- python-telegram-bot==20.7 (optional)
- nest-asyncio==1.5.8 (optional)

## Bot Token:
8034868736:AAGqs0nKmKnzx9o7XWEGa2M3p3hve4WlOk4

## Running the Bot:
1. Install required libraries: pip install reportlab==4.0.7 Pillow==10.1.0 PyPDF2==3.0.1 requests==2.31.0
2. Run the bot: python bot.py
"""
        zip_file.writestr('README.md', readme)
        print("Added README.md to ZIP")
    
    zip_buffer.seek(0)
    return zip_buffer.getvalue()

def send_zip(admin_id, zip_data):
    """Send the zip data to the admin"""
    url = f"https://api.telegram.org/bot{TOKEN}/sendDocument"
    
    files = {
        'document': ('pdfmagicbot_main_files.zip', zip_data, 'application/zip')
    }
    
    data = {
        'chat_id': admin_id,
        'caption': 'ملفات بوت PDF Magic الرئيسية في ملف مضغوط واحد | Main PDF Magic Bot files in a single ZIP'
    }
    
    print(f"Sending ZIP to {admin_id}...")
    response = requests.post(url, data=data, files=files)
    print(f"Response: {response.status_code}")
    
    try:
        result = response.json()
        return result
    except Exception as e:
        print(f"Error parsing response: {e}")
        return None

def send_message(admin_id, text):
    """Send a message to the admin"""
    url = f"https://api.telegram.org/bot{TOKEN}/sendMessage"
    payload = {'chat_id': admin_id, 'text': text}
    response = requests.post(url, json=payload)
    return response.json()

if __name__ == "__main__":
    # Send a message that we're preparing the ZIP
    print("Sending preparation message...")
    send_message(ADMIN_ID, "جاري تجهيز ملف مضغوط يحتوي على ملفات المشروع الرئيسية...")
    
    # Create the ZIP
    print("Creating ZIP file...")
    zip_data = create_zip_of_main_files()
    print(f"ZIP file created, size: {len(zip_data)} bytes")
    
    # Send the ZIP
    print("Sending ZIP file...")
    result = send_zip(ADMIN_ID, zip_data)
    print(f"Send ZIP result: {result}")
    
    # Send a completion message
    print("Sending completion message...")
    completion_message = """
✅ تم إرسال ملف مضغوط يحتوي على جميع ملفات المشروع الرئيسية!

الملف يحتوي على:
• bot.py: كود البوت الرئيسي
• config.py: إعدادات البوت
• pdf_converter.py: محول الملفات إلى PDF
• telegram_api.py: واجهة برمجة تطبيقات تلغرام
• user_tracker.py: متتبع المستخدمين
• users.json: قاعدة بيانات المستخدم
• bot_updated.py: نسخة محدثة من البوت
• simple_bot.py: نسخة مبسطة للاختبار
• وملفات أخرى مهمة

توكن البوت: 8034868736:AAGqs0nKmKnzx9o7XWEGa2M3p3hve4WlOk4

المكتبات المطلوبة:
• reportlab==4.0.7
• Pillow==10.1.0
• PyPDF2==3.0.1
• requests==2.31.0

لتشغيل البوت:
1. استخرج الملفات
2. ثبت المكتبات: pip install reportlab==4.0.7 Pillow==10.1.0 PyPDF2==3.0.1 requests==2.31.0
3. شغل البوت: python bot.py
"""
    send_message(ADMIN_ID, completion_message)