"""
Script to send all project files in a single ZIP file
This version uses a simpler approach to avoid timeout issues
"""
import os
import requests
import zipfile
import tempfile
import subprocess

# Bot token
TOKEN = "8034868736:AAGqs0nKmKnzx9o7XWEGa2M3p3hve4WlOk4"
ADMIN_ID = "7971415230"

def create_zip_file():
    """Create a zip file with all important files"""
    # Create a temporary directory
    with tempfile.TemporaryDirectory() as temp_dir:
        zip_path = os.path.join(temp_dir, "pdfmagicbot_complete.zip")
        
        # Use system zip command for better performance
        cmd = f"zip -r {zip_path} . -x '__pycache__/*' -x '.git/*' -x '.upm/*' -x '.config/*' -x '*.pyc'"
        print(f"Running command: {cmd}")
        subprocess.run(cmd, shell=True, check=True)
        
        return zip_path

def send_zip_file(admin_id, zip_path):
    """Send the zip file to the admin"""
    url = f"https://api.telegram.org/bot{TOKEN}/sendDocument"
    
    print(f"Sending ZIP file to {admin_id}...")
    
    with open(zip_path, 'rb') as zip_file:
        files = {'document': ('pdfmagicbot_complete.zip', zip_file)}
        data = {
            'chat_id': admin_id,
            'caption': 'جميع ملفات مشروع بوت PDF Magic في ملف مضغوط واحد | All PDF Magic Bot project files in a single ZIP'
        }
        
        print("Sending POST request...")
        response = requests.post(url, data=data, files=files)
        print(f"Response status code: {response.status_code}")
        
        try:
            result = response.json()
            print(f"Response: {result}")
            return result
        except Exception as e:
            print(f"Error parsing response: {e}")
            return None

def notify_admin(admin_id, message):
    """Send a notification message to the admin"""
    url = f"https://api.telegram.org/bot{TOKEN}/sendMessage"
    payload = {'chat_id': admin_id, 'text': message}
    
    try:
        response = requests.post(url, json=payload)
        return response.json()
    except Exception as e:
        print(f"Error sending notification: {e}")
        return None

if __name__ == "__main__":
    # Notify admin that we're preparing the ZIP
    notify_admin(ADMIN_ID, "جاري تجهيز ملف مضغوط يحتوي على جميع ملفات المشروع. هذا قد يستغرق بضع ثوان...")
    
    try:
        # Create the ZIP file
        print("Creating ZIP file...")
        zip_path = create_zip_file()
        print(f"ZIP file created at: {zip_path}")
        
        # Send the ZIP file
        send_zip_file(ADMIN_ID, zip_path)
        
        # Send a confirmation message
        notify_admin(ADMIN_ID, """
✅ تم إرسال ملف مضغوط يحتوي على جميع ملفات المشروع!

الملف يحتوي على:
• كل ملفات البوت (bot.py, config.py, pdf_converter.py, telegram_api.py, user_tracker.py...)
• ملفات التكوين (pyproject.toml, replit.nix...)
• ملفات البيانات (users.json)
• ملفات التشغيل البديلة (bot_updated.py, simple_bot.py...)

توكن البوت: 8034868736:AAGqs0nKmKnzx9o7XWEGa2M3p3hve4WlOk4

للتشغيل:
1. استخرج الملفات
2. ثبت المكتبات: pip install reportlab Pillow PyPDF2 requests
3. شغل البوت: python bot.py

المكتبات المطلوبة:
• reportlab==4.0.7
• Pillow==10.1.0
• PyPDF2==3.0.1
• requests==2.31.0
""")
    
    except Exception as e:
        print(f"Error: {e}")
        notify_admin(ADMIN_ID, f"حدث خطأ أثناء إنشاء الملف المضغوط: {e}")